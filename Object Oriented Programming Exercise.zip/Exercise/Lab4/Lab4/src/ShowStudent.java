
public class ShowStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student John = new Student(1234, 12.0, 9.0);
		System.out.println("GPA: " + John.getGPA());
		System.out.println("ID: " + John.getID());
		System.out.println("Points: " + John.getPoints());
		System.out.println("Credit hours earned: " + John.getCreditHours());
	}

}
