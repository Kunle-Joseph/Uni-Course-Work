
public class TestSandwich {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sandwich Ham = new Sandwich();
		Ham.setMainIngredient("Ham");
		Ham.setBreadType("Wheat");
		Ham.setPrice(2.3);
		System.out.println("Main ingredient: "+ Ham.getMainIngredient());
		System.out.println("Bread type: " + Ham.getBreadType());
		System.out.println("Price: " + Ham.getPrice());
	}

}
