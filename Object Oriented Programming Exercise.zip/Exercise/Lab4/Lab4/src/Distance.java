
public class Distance {
	private double speed;
	private int hours;
	
	public Distance(double S, int H) {
		speed = S;
		hours = H;
	}
	public void setSpeed(double S) {
		speed = S;
	}
	public void setHours(int H) {
		hours = H;
	}
	public double getSpeed() {
		return speed;
	}
	public int getHours() {
		return hours;
	}
	public double getDistance() {
		return speed * hours;
	}
}
