
public class Student {
	private int ID;
	private double GPA, creditHours, points;
	
	public Student(int id, double p, double credit) {
		ID = id;
		points = p;
		creditHours = credit;
	}
	public void setID(int id) {
		ID = id;
	}
	public void setGPA(double gpa) {
		GPA = gpa;
	}
	public void setCreditHours(double credit) {
		creditHours = credit;
	}
	public int getID() {
		return ID;
	}
	public double getGPA() {
		GPA = points / creditHours;
		return GPA;
	}
	public double getCreditHours() {
		return creditHours;
	}
	public double getPoints() {
		return points;
	}
	public Student() {
		ID = 9999;
		points = 12;
		creditHours = 3;
	}
}
