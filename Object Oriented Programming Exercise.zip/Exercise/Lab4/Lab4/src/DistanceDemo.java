import java.util.Scanner;
public class DistanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double speed; // Vehicle's speed
		int maxHours = 24; // Number of hours
		int period; // Counter for time periods
		// Create a Scanner object for keyboard input.
		Scanner keyboard = new Scanner(System.in);
		// Get the speed.
		System.out.print("Enter the vehicle's speed: ");
		speed = keyboard.nextDouble();
		System.out.println();
		period = 1;
		while (period <= maxHours){
			Distance D = new Distance(speed, period);
			System.out.println(period +"\t\t" + D.getDistance());
			period++;
		}
	}

}
