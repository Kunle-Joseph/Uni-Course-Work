
public class ShowStudent2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student Joey = new Student();
		System.out.println("GPA: " + Joey.getGPA());
		System.out.println("ID: " + Joey.getID());
		System.out.println("Points: " + Joey.getPoints());
		System.out.println("Credit hours earned: " + Joey.getCreditHours());
	}

}
