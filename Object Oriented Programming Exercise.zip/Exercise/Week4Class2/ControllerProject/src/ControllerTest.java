
public class ControllerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Controller test1 = new Controller();
		Controller test2 = new Controller();
		System.out.print("Temperature: ");
		test1.accessTemperature();
	}

}
