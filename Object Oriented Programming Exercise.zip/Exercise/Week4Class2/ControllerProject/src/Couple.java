import java.time.*;

public class Couple {
	private Person husband = new Person();
	private Person wife = new Person();
	
	public Couple() {
		
	}
	
	public Couple(Person Husband, Person Wife) {
		husband = Husband;
		wife = Wife;
	}
	
	public void showInfo() {
		System.out.println("Husband Name: " + husband.getFirstName() + " " + husband.getLastName());
		System.out.println("Husband Birthday: " + husband.getbirthDate());
		System.out.println();
		System.out.println("Wife Name: " + wife.getFirstName() + " " + wife.getLastName());
		System.out.println("Wife Birthday: " + wife.getbirthDate());
	}
	
	public String getHusbandFirstName() {
		return husband.getFirstName();
	}
	
	public void setHusbandFirstName( String first) {
		husband.setFirstName(first); 
	}
	
	public String getHusbandLastName() {
		return husband.getLastName();
	}
	
	public void setHusbandLastName( String last) {
		wife.setLastName(last); 
	}
	
	public String getWifeFirstName() {
		return wife.getFirstName();
	}
	
	public void setWifeFirstName( String first) {
		wife.setFirstName(first); 
	}
	
	public String getWifeLastName() {
		return wife.getLastName();
	}
	
	public void setWifeLastName( String last) {
		wife.setLastName(last); 
	}
	
	public LocalDate getHusbandbirthDate() {
		return husband.getbirthDate();
	}
	
	public void setHusbandBirthDate(LocalDate date) {
		husband.setBirthDate(date);
	}
	
	public LocalDate getWifebirthDate() {
		return wife.getbirthDate();
	}
	
	public void setwifeBirthDate(LocalDate date) {
		wife.setBirthDate(date);
	}
	public void setCouple(Person Husband, Person Wife) {
		husband = Husband;
		wife = Wife;
	}
}
