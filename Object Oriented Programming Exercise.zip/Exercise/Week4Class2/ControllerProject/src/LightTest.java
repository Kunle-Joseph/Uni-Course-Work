
public class LightTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Light bulb1 = new Light();
		bulb1.brighten();
		bulb1.brighten();
		bulb1.status();
		Light bulb2 = new Light(true);
		bulb2.dim();
		bulb2.dim();
		bulb2.status();		
	}

}
