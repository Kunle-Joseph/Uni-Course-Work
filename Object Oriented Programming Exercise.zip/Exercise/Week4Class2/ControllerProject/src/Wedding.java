import java.time.*;
public class Wedding {
	private LocalDate weddingDay;
	private String location;
	private Couple celebrants = new Couple();
	
	public void Wedding() {
		
	}
	
	public Wedding(String Location, Couple couple, LocalDate date) {
		weddingDay = date;
		location = Location;
		celebrants = couple;
	}

	public void setWeddingDay(LocalDate date) {
		weddingDay = date;
	}
	public LocalDate getWeddingDay() {
		return weddingDay;
	}
	public String getHusbandName() {
		return celebrants.getHusbandFirstName() + " " +
				celebrants.getHusbandLastName();
	}
	public String getWifeName() {
		return celebrants.getWifeFirstName() + " " +
				celebrants.getWifeLastName();
	}
	public void showInfo() {
		System.out.println("Couple: " + celebrants.getHusbandFirstName() + " " +
				celebrants.getHusbandLastName() + " and " + 
				celebrants.getWifeFirstName() + " " +
				celebrants.getWifeLastName());
		System.out.println("Location: " + location);
		System.out.println("Wedding date: " + weddingDay);
	}
	public void setCouple(Couple couple) {
		celebrants = couple;
	}
}
