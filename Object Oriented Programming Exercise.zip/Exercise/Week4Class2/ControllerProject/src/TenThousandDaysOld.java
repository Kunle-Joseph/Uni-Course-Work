import java.time.*;
public class TenThousandDaysOld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate birthDay = LocalDate.of(2003, 2, 14);
		final int Factor = 10000;
		System.out.println(" I will be " + Factor + " days old on " +
		birthDay.plusDays(Factor));
	}

}
