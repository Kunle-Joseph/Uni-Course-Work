import java.time.*;

public class TestWedding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person John = new Person("John", "Doe", LocalDate.of(1995, 04, 12));
		Person Jane = new Person("Jane", "Phillips", LocalDate.of(1997, 02, 014));
		
		John.showInfo();
		System.out.println();
		Jane.showInfo();
		System.out.println();
		
		Couple Doe = new Couple(John, Jane);
		Doe.showInfo();
		System.out.println();
		
		Wedding london = new Wedding("London", Doe, LocalDate.of(2022, 2, 14));
		london.showInfo();
	}
	
}
