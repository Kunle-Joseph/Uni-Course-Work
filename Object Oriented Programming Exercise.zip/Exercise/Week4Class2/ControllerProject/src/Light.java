
public class Light {
	private boolean _On;
	//couldnt remember how to use enum
	private int brightness = 1;// 1- normal, 2-bright, 0-dim
	public Light() {
		_On = false;
	}
	public Light(boolean on) {
		_On = on;
	}
	public void on() {
		_On = true;
	}
	
	public void off() {
		_On = false;
	}
	
	public void brighten() {
		if(_On) {
			if(brightness < 2) brightness++;
			else System.out.println("At max!");			
		} else System.out.println("Bulb is off");
	}
	
	public void dim() {
		if(_On) {
			if(brightness > 0) brightness--;
			else System.out.println("At minimum!");	
		} else System.out.println("Bulb is off");
	}
	
	public void status() {
		if(_On) 
			System.out.println("The bulb is on with brightness of " + brightness);
		else
			System.out.println("The bulb is off");
		
	}
}
