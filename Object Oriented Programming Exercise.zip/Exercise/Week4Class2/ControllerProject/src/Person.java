import java.time.*;
public class Person {
	private String FirstName, LastName;
	private LocalDate birthDate;
	public Person() {
		
	}
	public Person(String first, String last, LocalDate date) {
		FirstName  = first;
		LastName = last;
		birthDate = date;
	}
	public Person(String first, String last) {
		FirstName  = first;
		LastName = last;
	}
	
	public String getFirstName() {
		return FirstName;
	}
	
	public void setFirstName( String first) {
		FirstName  = first;
	}
	
	public String getLastName() {
		return LastName;
	}
	
	public void setLastName(String last) {
		LastName  = last;
	}
	
	public LocalDate getbirthDate() {
		return birthDate;
	}
	
	public void setBirthDate(LocalDate date) {
		birthDate = date;
	}
	
	public void showInfo() {
		System.out.println("Name: " + FirstName + " " + LastName);
		System.out.println("Birthday: " + birthDate);
	}
}
