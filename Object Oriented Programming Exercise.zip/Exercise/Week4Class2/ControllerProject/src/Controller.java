
public class Controller {
	private double temperature;
	
	public Controller() {
		double defaultT = 293.0;
		setTemperature(defaultT);
	}
	
	public Controller(double initialT) {
		setTemperature(initialT);
	}
	
	public void setTemperature(double T) {
		temperature = T;
	}
	
	private double getTemperature() {
		return temperature;
	}
	
	public void accessTemperature() {
		System.out.println(getTemperature());
	}
}
