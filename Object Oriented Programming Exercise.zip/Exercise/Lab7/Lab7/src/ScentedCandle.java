
public class ScentedCandle extends Candle{
	private String scent;
	
	public ScentedCandle(String s, String c, double h) {
		super(c, h);
		this.scent = s;
		super.setPrice(3);
	}
	
	public void setScent(String scent) {
		this.scent = scent;
	}
	
	public String getScent() {
		return this.scent;
	}
	
	public void setHeight(double height) {
		super.setHeight(height);
		super.setPrice(3);
	}
}
