
public class Derived2 extends Derived1{
	public void finalize() {
		System.out.println("Derived2.finalize()");
		System.gc();
	}
}
