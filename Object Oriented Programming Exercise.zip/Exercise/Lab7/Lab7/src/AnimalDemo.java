
public class AnimalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal doge = new Animal();
		System.out.println(doge.toString());
	}

}
