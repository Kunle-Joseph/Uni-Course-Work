
public class TwoMethods {
	public void m1() {
		System.out.println("m1");
		m2();
	}
	
	public void m2() {
		System.out.println("m2");
	}
	
	public String toString() {
		return getClass().getName();
	}
}
