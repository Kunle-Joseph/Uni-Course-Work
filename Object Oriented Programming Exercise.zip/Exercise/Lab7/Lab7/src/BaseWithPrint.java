
public class BaseWithPrint {
	public BaseWithPrint() {
		print();
	}
	
	public void print() {
		System.out.println("BaseWithPrint.print");
	}
}
