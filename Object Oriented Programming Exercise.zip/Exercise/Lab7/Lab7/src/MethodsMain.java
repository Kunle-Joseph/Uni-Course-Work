
public class MethodsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TwoMethods test = new TwoMethods();
		System.out.println(test.toString());
		test.m1();
		
		Methods test2 = new Methods();
		test2.m2();
	}

}
