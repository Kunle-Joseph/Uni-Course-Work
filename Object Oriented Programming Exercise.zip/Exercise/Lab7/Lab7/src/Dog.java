
public class Dog extends Animal{
	public void Bark() {
		System.out.println("Bark");
	}
	
	public void Bark(int i) {
		System.out.println("Howl");
	}
	
	public void Bark(boolean b) {
		System.out.println("Whine");
	}
	
	public String toString() {
		return getClass().getName();
	}
}
