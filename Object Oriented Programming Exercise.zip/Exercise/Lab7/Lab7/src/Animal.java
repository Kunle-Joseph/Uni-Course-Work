
public class Animal {
	
	public Animal(){
		System.out.println("New animal is defined");
	}
	
	public void method_Animal() {
		
	}
	
	public String method_Animal(String s) {
		return s;
	}
	
	public boolean method_Animal(boolean b) {
		return b;
	}
	
	public String toString() {
		return getClass().getName();
	}

}
