
public class Derived1 extends Base{
	public void finalize() {
		System.out.println("Derived1.finalize()");
		System.gc();
	}
}
