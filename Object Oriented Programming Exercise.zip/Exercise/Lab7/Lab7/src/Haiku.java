
public class Haiku extends Poem{
	public Haiku(String name) {
		super(name, 3);
	}
}
