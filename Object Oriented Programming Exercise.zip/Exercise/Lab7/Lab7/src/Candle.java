
public class Candle {
	private String color;
	private double height, price;
	
	public Candle() {
		
	}
	
	public Candle(String color, double height) {
		this.color = color;
		this.height = height;
		setPrice(2);
	}
	
	public String getColor() {
		return this.color;
	}
	
	public double getPrice() {
		return this.price;
	}
	
	public double getHeight() {
		return this.height;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public void setHeight(double height) {
		this.height = height;
		setPrice(2);
	}
	
	public void setPrice(double perInch) {
		price = this.height * perInch;
	}
}
