
public class DerivedWithPrint extends BaseWithPrint{
	int i = 21;
	public void print() {
		System.out.println("i = " + i);
	}
}
