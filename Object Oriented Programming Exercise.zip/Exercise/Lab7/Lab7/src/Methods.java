
public class Methods extends TwoMethods{
	public void m2() {
		System.out.println("m2 derived");
	}
}
