
public class DemoPoems {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Couplet C = new Couplet("Sonnet 52");
		Haiku H = new Haiku("The Old Pond");
		Limerick L = new Limerick("Selina the Ballerina");
		
		System.out.println("Couplet: " + C.getName() + " with " +
		C.getLines() + " lines");
		System.out.println("Haiku: " + H.getName() + " with " +
				H.getLines() + " lines");
		System.out.println("Limerick: " + L.getName() + " with " +
				L.getLines() + " lines");
	}

}
