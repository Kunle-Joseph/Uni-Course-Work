
public class Base {
	public void finalize() {
		System.out.println("Base.finalize()");
		System.gc();
	}
}
