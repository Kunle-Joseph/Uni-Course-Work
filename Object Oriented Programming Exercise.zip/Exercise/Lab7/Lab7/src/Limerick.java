
public class Limerick extends Poem{
	public Limerick(String name) {
		super(name, 5);
	}
}
