
public class DemoWithPrint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DerivedWithPrint dp = new DerivedWithPrint();
		dp.print();//shows i = 0 /n i = 21
		//calls print(), twice one in inner class and one in outer
	}

}
