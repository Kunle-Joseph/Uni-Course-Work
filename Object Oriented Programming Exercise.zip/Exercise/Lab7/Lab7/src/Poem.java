
public class Poem {
	private String name;
	private int lines;
	
	public Poem(String name, int lines) {
		this.name = name;
		this.lines = lines;
	}
	
	public int getLines() {
		return this.lines;
	}
	
	public String getName() {
		return this.name;
	}
}
