
public class DemoCandles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Candle nonScent = new Candle();
		nonScent.setColor("white");
		nonScent.setHeight(4);
		
		System.out.println(nonScent.getPrice());
		
		ScentedCandle Scent = new ScentedCandle("Mint", "Blue" , 2);
		System.out.println(Scent.getPrice());
	}

}
