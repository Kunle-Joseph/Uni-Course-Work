
public class A {
	int a = 10;
	public interface B{
		void print();
		int a = 9;
	}
}
