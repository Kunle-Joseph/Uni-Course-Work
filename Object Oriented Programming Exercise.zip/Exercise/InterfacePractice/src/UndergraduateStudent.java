
public class UndergraduateStudent extends Student{

	UndergraduateStudent(String id, String last) {
		super(id, last);
		setTuition();
	}

	public void setTuition() {
		 Tuition(4000);
	}

}
