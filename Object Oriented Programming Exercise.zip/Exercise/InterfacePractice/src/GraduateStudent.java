
public class GraduateStudent extends Student{

	GraduateStudent(String id, String last) {
		super(id, last);
		setTuition();
	}

	public void setTuition() {
		Tuition(6000);
	}

}
