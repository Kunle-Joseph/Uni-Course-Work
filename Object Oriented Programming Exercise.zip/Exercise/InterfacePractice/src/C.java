
public class C implements A.B{
	public void print() {
		System.out.println(a);
	}
}
