
public interface ExcellentStudent {
	int attendance = 80;
	double gpa = 3;
}
