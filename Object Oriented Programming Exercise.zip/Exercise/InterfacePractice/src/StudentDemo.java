
public class StudentDemo {

	public static void main(String[] args) {
		Student[] students = {
			new UndergraduateStudent("U2112", "Doe"),
			new GraduateStudent("U3135", "Jesse"),
			new UndergraduateStudent("N1122", "John"),
			new StudentAtLarge("U9814", "Davis"),
			new GraduateStudent("N3135", "James"),
			new StudentAtLarge("U8914", "Jane")
		};
		
		for (int i = 0; i < students.length; i++) {
			System.out.println("Tuition for " + students[i].getLastName() 
					+ ": " + students[i].getTuition());
		}
	}

}
