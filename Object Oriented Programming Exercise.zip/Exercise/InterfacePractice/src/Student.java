
public abstract class Student implements ExcellentStudent{
	private String id, last;
	private int tuition;
	
	Student(String id, String last){
		this.id = id;
		this.last = last;
	}
	
	public abstract void setTuition();
	
	public void setID(String id) {
		this.id = id;
	}
	
	public void setLastName(String last) {
		this.last = last;
	}
	
	public String getID() {
		return this.id;
	}
	
	public String getLastName() {
		return this.last;
	}
	
	public int getTuition() {
		return this .tuition;
	}
	
	protected void Tuition(int tuition) {
		this.tuition = tuition;
	}
	
	public boolean isStudentExcellent() {
		if(this.gpa >= 3 || this.attendance >= 80)return true;
		return false;
	}
}
