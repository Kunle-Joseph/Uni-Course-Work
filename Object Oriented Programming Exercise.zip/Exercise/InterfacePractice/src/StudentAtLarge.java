
public class StudentAtLarge extends Student {

	StudentAtLarge(String id, String last) {
		super(id, last);
		setTuition();
	}

	public void setTuition() {
		Tuition(2000);
	}

}
