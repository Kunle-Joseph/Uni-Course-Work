
public class ClassTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle circle = new Circle(2);
		System.out.println(circle.getArea());
	}

}
