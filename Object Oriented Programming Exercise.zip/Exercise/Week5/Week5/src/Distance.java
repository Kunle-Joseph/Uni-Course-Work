
public class Distance {
	private double speed;
	private int hours;
	
	public Distance(double s, int h) {
		this.speed = s;
		this.hours = h;
	}
	
	public void setSpeed(double s) {
		this.speed = s;
	}
	
	public double getSpeed() {
		return this.speed;
	}
	
	public void setHours(int h) {
		this.hours = h;
	}
	
	public int getHours() {
		return this.hours;
	}
}
