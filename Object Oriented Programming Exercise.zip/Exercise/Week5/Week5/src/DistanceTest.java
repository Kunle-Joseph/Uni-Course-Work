
public class DistanceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Distance A = new Distance(2.0, 4);
		Distance B = new Distance(2.6, 6);
		System.out.println(A.getSpeed());
		A.setSpeed(8);
		System.out.println(A.getSpeed());
		System.out.println(B.getSpeed());
	}

}
