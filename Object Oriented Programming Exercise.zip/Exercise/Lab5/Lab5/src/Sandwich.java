//Exercise 1a
public class Sandwich {
	private String main, bread;
	private double price;
	
	public Sandwich(String main, String bread,
			double price) {
		this.main = main;
		this.bread = bread;
		this.price = price;
	}
	
	public String getMain() {
		return main;
	}
	
	public String getBread() {
		return bread;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setMain(String main) {
		this.main = main;
	}
	
	public void setBread(String bread) {
		this.bread = bread;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
}
