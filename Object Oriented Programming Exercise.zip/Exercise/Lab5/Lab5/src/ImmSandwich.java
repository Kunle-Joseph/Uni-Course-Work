//exercise 1c
public class ImmSandwich {
	private final String main, bread;
	private final double price;
	
	public ImmSandwich(String main, String bread,
			double price) {
		this.main = main;
		this.bread = bread;
		this.price = price;
	}
}
