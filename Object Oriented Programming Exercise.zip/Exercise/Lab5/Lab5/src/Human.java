
public class Human {
	private final String firstName, lastName,
		middleName;
	public Human(String first, String middle, String last) {
		this.firstName = first;
		this.lastName = last;
		this.middleName = middle;
		System.out.println(this.output());
	}
	
	public Human() {
		this.firstName = "";
		this.lastName = "";
		this.middleName = "";
		System.out.println(this.output());
	}
	
	public Human(Human otherHuman) {
		this.firstName = otherHuman.getFirstName();
		this.lastName = otherHuman.getLastName();
		this.middleName = otherHuman.getMiddleName();
		System.out.println(this.output());
	}
	
	private String getFirstName() {
		return this.firstName;
	}
	
	private String getMiddleName() {
		return this.middleName;
	}
	
	private String getLastName() {
		return this.lastName;
	}
	
	private boolean isLastName(String last) {
		if(last == this.lastName) return true;
		return false;
	}
	private boolean isFirstName(String first) {
		if(first == this.firstName) return true;
		return false;
	}
	private boolean isMiddleName(String middle) {
		if(middle == this.middleName) return true;
		return false;
	}
	
	private String output() {
		return firstName + " " + middleName + " " + lastName;
	}
}
