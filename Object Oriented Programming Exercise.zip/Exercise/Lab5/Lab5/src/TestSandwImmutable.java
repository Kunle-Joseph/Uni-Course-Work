//exercise 1c
public class TestSandwImmutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sandwich tuna = new Sandwich("Tuna", "Wheat", 4.9);
		System.out.println(tuna.getBread());
		System.out.println(tuna.getMain());
		System.out.println(tuna.getPrice());
	}

}
