import java.util.Scanner;
public class TestHuman {
static Scanner console = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Enter your first name: ");
		String first = console.nextLine();
		System.out.print("Enter your middle name: ");
		String middle = console.nextLine();
		System.out.print("Enter your last name: ");
		String last = console.nextLine();
		
		Human Me = new Human(first, middle, last);
	}

}
