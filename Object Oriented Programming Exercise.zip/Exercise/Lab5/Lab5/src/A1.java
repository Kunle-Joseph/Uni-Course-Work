
public class A1 {
	private int i, j, k;

}
