//exercise 2
public class MyRadio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Radio myRadio = new Radio();
	System.out.println("Classic FM frequency: "
			+ myRadio.CLASSIC_FM);
	System.out.println("BBC Radio 3 frequency: " 
			+ myRadio.frequencyOfBBC(3));
	myRadio.listen();
	myRadio.setFrequency(myRadio.frequencyOfBBC(2));
	myRadio.listen();
	myRadio.setFrequency((float) 92.7);
	myRadio.listen();
	myRadio.setFrequency((float) 94.5);
	myRadio.listen();
	}

}
