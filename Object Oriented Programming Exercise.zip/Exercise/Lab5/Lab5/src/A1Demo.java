
public class A1Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A1 a = new A1();
	}

}
