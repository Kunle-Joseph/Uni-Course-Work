//Exercise 1b
public class TestSandwich {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sandwich ham = new Sandwich("Ham", "wheat", 5.25);
		System.out.println(ham.getBread());
		System.out.println(ham.getMain());
		System.out.println(ham.getPrice());
		ham.setBread("White");
		ham.setMain("Beef");
		ham.setPrice(5.5);
		System.out.println(ham.getBread());
		System.out.println(ham.getMain());
		System.out.println(ham.getPrice());
	}

}
