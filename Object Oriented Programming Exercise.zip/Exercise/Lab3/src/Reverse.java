//#2a
public class Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		reverse(12345);
	}

	public static void reverse(int number) {
		int reversed = 0;
		while(number != 0) {
		    
		      // get last digit from num
		      int digit = number % 10;
		      reversed = reversed * 10 + digit;

		      // remove the last digit from num
		      number /= 10;
		    }
		System.out.println(reversed);
	}
}
