
public class RectangleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle A = new Rectangle(4, 40);
		Rectangle B = new Rectangle(3.5, 35.9);
		A.setColor("red");
		B.setColor("red");
		System.out.println(A.getColor());
		System.out.println(A.getHeight());
		System.out.println(A.getWidth());
		System.out.println(A.getArea());
		System.out.println(A.getPerimeter());
		System.out.println(B.getColor());
		System.out.println(B.getHeight());
		System.out.println(B.getWidth());
		System.out.println(B.getPerimeter());
		System.out.println(B.getArea());
	}

}
