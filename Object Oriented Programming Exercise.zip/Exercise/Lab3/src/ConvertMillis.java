//#2c
public class ConvertMillis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(convertMillis(555550000));
	}

	public static String convertMillis(long millis) {
		long remainder = 0, minutes = 0, seconds = 0;
		long hours = (millis / 1000) / 3600;
		if (hours >= 1) {
			remainder = (millis/1000) %3600;
			minutes = (remainder) / 60;
			seconds = (remainder ) % 60;
			return hours + ":" + minutes + ":" + seconds;
		}
		else if (((millis / 1000) / 60) >= 1){
			minutes = (millis/1000) / 60;
			seconds = (millis / 1000) % 60;
			return "0:" + minutes + ":" + seconds;
		}
		else {
			seconds = millis /1000;
			return "0:0:"  + seconds;
		}
	}
}
