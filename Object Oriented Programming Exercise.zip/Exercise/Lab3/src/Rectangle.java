//3
public class Rectangle {
	private double width = 1, height = 1;
	private String color = "white";
	
	public Rectangle(){
		
	}
	public Rectangle(double x, double y){
		width = x;
		height = y;
	}
	
	public double getArea() {
		return width * height;
	}
	
	public double getPerimeter() {
		return (2 *width) + (2 * height);
	}
	
	public void setColor(String newColor) {
		color = newColor;
	}
	
	public String getColor() {
		return color;
	}
	
	public void setWidth(double x) {
		width = x;
	}
	
	public void setHeight(double x) {
		height = x;
	}
	
	public double getHeight() {
		return height;
	}
	
	public double getWidth() {
		return width;
	}
}
