
public class Exercise1a {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float tuition = 16000;
		double increase = 0.05;
		for(int i = 0; i < 10; i++)
			tuition += (increase * tuition);
		System.out.println(tuition);
	}

}
