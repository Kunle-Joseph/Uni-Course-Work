
public class toLowerCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(upperCaseToLowerCase('A'));
	}

	public static char upperCaseToLowerCase(char ch) {
		ch = Character.toLowerCase(ch);
		return ch;
	}
}
