//#2b
public class Summing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(summing(6));
	}

	public static double summing(int i) {
		double sum = 0;
		for(double j = 1; j <= i; j++) {
			sum += (j / (j + 1));
		}
		return sum;
	}
}
