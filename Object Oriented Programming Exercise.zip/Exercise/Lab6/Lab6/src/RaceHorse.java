
public class RaceHorse extends Horse{
	private int races;
	
	public RaceHorse(String name, String color, int bYear, int races) {
		super(name, color, bYear);
		this.races = races;
	}
	
	public int getRaces() {
		return this.races;
	}
	
	public void setRaces(int races) {
		this.races = races;
	}
	
	public void MethodHorse() {
		System.out.println("I am methodHorse in the RaceHorse class");
	}
}
