
public class C extends A{
	B b = new B();
}
