
public class UseVehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car ford = new Car(21);
		MotorCycle toyota = new MotorCycle(19);
		
		System.out.println(ford.toString());
		System.out.println(toyota.toString());
	}

}
