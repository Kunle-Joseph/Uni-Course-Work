
public class Car extends Vehicle{
	public Car(int m) {
		super(4, m);
	}
}
