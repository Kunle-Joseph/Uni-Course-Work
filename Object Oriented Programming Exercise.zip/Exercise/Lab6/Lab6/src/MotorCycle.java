
public class MotorCycle extends Vehicle{
	public MotorCycle(int m) {
		super(2, m);
	}
}
