
public class CargoShip extends Ship{
	private int tonnage;
	
	CargoShip(String n, String y, int t){
		super(n,y);
		this.tonnage = t;
	}
	
	public void setTonnage(int t) {
		this.tonnage = t;
	}
	
	public int getTonnage() {
		return this.tonnage;
	}
	
	public String toString() {
		return "Ship Name: " + this.getName() + "\nCargo capacity: " 
				+ this.tonnage;
	}
}
