
public class Horse {
	private String name, color;
	private int bYear;
	
	public void MethodHorse() {
		System.out.println("I am methodHorse in the Horse class");
	}
	
	public Horse() {System.out.println("I am the default "
			+ "constructor of the class Horse");}
	
	public Horse(String name, String color, int bYear) {
		this.name  = name;
		this.color = color;
		this.bYear = bYear;
	}
	
	public String getName() {
		return name;
	}
	
	public String getColor() {
		return color;
	}
	
	public int getBirthYear() {
		return bYear;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public void setBirthYear(int bYear) {
		this.bYear = bYear;
	}
}
