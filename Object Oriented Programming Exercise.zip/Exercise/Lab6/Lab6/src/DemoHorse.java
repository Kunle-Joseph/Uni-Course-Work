//Exercise 1
public class DemoHorse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Horse Stallion = new Horse();
		Stallion.setBirthYear(2017);
		Stallion.setColor("Brown");
		Stallion.setName("Meg");
		Stallion.MethodHorse();
		
		RaceHorse Thoroughbred = new RaceHorse("Lenny", "Black", 2018, 21);
		Thoroughbred.setRaces(22);
		System.out.println(Thoroughbred.getRaces());
		Thoroughbred.MethodHorse();
	}

}
