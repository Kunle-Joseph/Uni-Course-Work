
public class Tank {
	static int counter;
	int id = counter++;
	boolean full = false;
	
	public Tank() {
		System.out.println("Tank " + id + " created");
	}
	
	public void fill() {
		if(full == false) {
			full = true;
			System.out.println("Tank " + id + " now full");
		}
		else System.out.println("Tank " + id + " already full");
	}
	
	public void empty() {
		if(full == true) {
			full = false;
			System.out.println("Tank " + id + " now empty");
		}
		else System.out.println("Tank " + id + " already empty");
	}
	
	public void finalize() {
		if(full) {
			System.out.println(
			"Error: tank " + id + " must be empty at cleanup");
		}
		else {
			System.out.println("Tank " + id + " cleaned up OK");
		}
	}
	
	public String toString() {
		return "Tank " + id;
	}
}
