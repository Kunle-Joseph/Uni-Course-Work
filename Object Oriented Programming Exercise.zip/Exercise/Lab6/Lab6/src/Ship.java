
public class Ship {
	private String name, yearBuilt;
	public static int count = 0;
	
	public Ship(String n, String y) {
		this.name = n;
		this.yearBuilt = y;
		count++;
	}
	
	public void setName(String n) {
		this.name = n;
	}
	
	public void setYearBuilt(String y) {
		this.yearBuilt = y;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getYearBuilt() {
		return this.yearBuilt;
	}
	
	public String toString() {
		return this.name + " is the ships name. Built in " + this.yearBuilt;
	}
}
