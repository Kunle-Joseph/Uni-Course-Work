
public class A {
	public A() {
		System.out.println("Class A");
	}
	
	public A(String s) {
		System.out.println("Class A: " + s);
	}
	
	void a() {
		System.out.println("I am in A class");
	}
}
