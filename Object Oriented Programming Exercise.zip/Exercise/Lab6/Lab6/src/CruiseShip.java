
public class CruiseShip extends Ship{
	private int passengers;
	
	CruiseShip(String n, String y, int p){
		super(n,y);
		this.passengers = p;
	}
	
	public void setPassengers(int p) {
		this.passengers = p;
	}
	
	public int getPassengers() {
		return this.passengers;
	}
	
	public String toString() {
		return "Ship Name: " + this.getName() + "\nMaximum Passengers: " 
				+ this.passengers;
	}
}
