
public class Vehicle {
	//Superclass
	private int wheels, mpg;
	
	public Vehicle(int w, int m) {
		this.wheels = w;
		this.mpg = m;
	}
	
	public String toString() {
		return "Number of wheels: " + wheels
				+ "\nMiles per gallon: " + mpg;
	}
}
