
public class B {
	public B() {
		System.out.println("Class B");
	}
	public B(String s) {
		System.out.println("Class B: " + s);
	}
	
	void b() {
		System.out.println("I am in B class");
	}
}
