
public class ShipDemo {

	public static void main(String[] args) {
		// Create an array of Ship references.
		Ship[] ships = new Ship[10];
		// Assign Ship objects to the array elements.
		ships[0] = new Ship("Lolipop", "1960");
		ships[1] = new CruiseShip("Disney Magic", "1998", 2400);
		ships[2] = new CargoShip("Black Pearl", "1800", 50000);
		ships[3] = new Ship("Raspberry", "1989");
		// Call each object's toString method.
		for (int index = 0; index < ships[0].count; index++)//just testing if static helps
		{
		System.out.println(ships[index]);
		//outputs toString() without toString being visibly called
		System.out.println("----------------------");
		}
	}
}
