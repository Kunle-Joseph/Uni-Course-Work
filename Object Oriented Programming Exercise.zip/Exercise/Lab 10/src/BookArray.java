
public class BookArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book books[] = {
				new Fiction("Star Wars"),
				new Fiction("Star Trek"),
				new Fiction("SpiderMan"),
				new Fiction("Batman"),
				new Fiction("One Piece"),
				new NonFiction("Into Thin Air"),
				new NonFiction("Holes"),
				new NonFiction("The Right Stuff"),
				new NonFiction("In Cold Blood"),
				new NonFiction("I Give Up")
		};
		
		for(int i = 0; i < books.length; i++)
			books[i].showInfo();
	}

}
