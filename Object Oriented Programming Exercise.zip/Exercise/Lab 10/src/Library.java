
public interface Library {
	String name = "Public Library";
	double capacity = 2000;
	double squareMeter = 50;
	
	abstract String getName();
	abstract double getCapacity();
	abstract double getSquare();
}
