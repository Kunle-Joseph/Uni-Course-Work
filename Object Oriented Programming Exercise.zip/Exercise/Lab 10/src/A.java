//exercise 3
public interface A {
	public void a();
	public void a1();
}
