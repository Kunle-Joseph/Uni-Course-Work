
public class Fiction extends Book implements Library{

	public Fiction(String title) {
		super(title);
		setPrice();
	}

	public String getName() {
		return this.name;
	}

	public double getCapacity() {
		return this.capacity;
	}

	public double getSquare() {
		return this.squareMeter;
	}

	public void setPrice() {
		this.price = 29.99;
	}
	
	public void showInfo() {
		System.out.println("Title: " + this.getTitle()
			+ "\nPrice: " + this.getPrice() + "\n");
	}
}
