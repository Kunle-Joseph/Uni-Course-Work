
public abstract class Book implements Library {
	private String title;
	protected double price;
	private int pages;
	
	public Book(String title) {
		this.setTitle(title);
	}

	public String getTitle() {
		return title;
	}

	protected void setTitle(String title) {
		this.title = title;
	}

	public double getPrice() {
		return price;
	}

	public abstract void setPrice();
	public abstract void showInfo();

	public double getPages() {
		return pages;
	}
}
