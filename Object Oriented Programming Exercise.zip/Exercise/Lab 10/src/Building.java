
public interface Building {

}
