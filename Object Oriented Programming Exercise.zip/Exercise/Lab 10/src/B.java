//ex 3
public interface B {
	public void b();
	public void b1();
}
