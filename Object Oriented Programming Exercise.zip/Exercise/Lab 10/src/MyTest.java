
public class MyTest {

	public static void main(String[] args) {
		Fiction f = new Fiction("Harry Potter");
		NonFiction n = new NonFiction("Into the Wild");
		System.out.println("Books in the " + f.getName() + "\n");
		f.showInfo();
		n.showInfo();
	}

}
