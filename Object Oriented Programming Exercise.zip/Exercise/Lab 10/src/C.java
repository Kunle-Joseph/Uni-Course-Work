//ex 3
public interface C {
	public void c();
	public void c1();
}
