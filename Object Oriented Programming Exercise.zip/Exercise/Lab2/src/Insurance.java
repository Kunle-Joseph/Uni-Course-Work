import java.util.Scanner;
public class Insurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int currentYear, birthYear;
		Scanner in = new Scanner(System.in);
		//getting values
		System.out.println("Please enter your birth year: ");
		birthYear = in.nextInt();
		System.out.println("Please enter the current year: ");
		currentYear = in.nextInt();
		//output
		System.out.println("Returned amount is: $" + premium(currentYear, birthYear));
	}

	public static int premium(int currentYear,int birthYear) {
		//calculating premium
		int age = currentYear - birthYear;
		int premium = 20 * ((age / 10) + 15);
		return premium;
	}
}
