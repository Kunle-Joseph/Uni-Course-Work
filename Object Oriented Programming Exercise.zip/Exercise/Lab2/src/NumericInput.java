import java.util.Scanner;
public class NumericInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int integer;
		long longInteger;
		float realNumber;
		double doubleReal;
		String string1;
		String string2;
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter an integer, a long integer, a floating-point\r\n"
				+ "number, another floating-point number, and a string.\r\n"
				+ "Separate each with a return.");
		
		integer = in.nextInt();
		longInteger = in.nextLong();
		realNumber = in.nextFloat();
		doubleReal = in.nextDouble();
		string1 = in.nextLine();
		string2 = in.nextLine();
		
		System.out.println("Here's what you entered: ");
		System.out.println(integer);
		System.out.println(longInteger);
		System.out.println(realNumber);
		System.out.println(doubleReal);
		System.out.println(string1);
		System.out.println(string2);
	}

}
