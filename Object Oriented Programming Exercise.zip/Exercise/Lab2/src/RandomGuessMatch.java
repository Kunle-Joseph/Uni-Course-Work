import java.util.Scanner;
import java.lang.Math;
public class RandomGuessMatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner guess = new Scanner(System.in);
		int MIN = 1, MAX = 5;
		int answer = 1 + (int)(Math.random() * MAX);
		int input = 0;
		do {
			System.out.println("Guess a number between " + MIN + " and "
					+ MAX);
			input = guess.nextInt();
			if(input == answer) System.out.println("Congrats!!!"
					+ " the answer was " + answer);
			else System.out.println("Wrong, but the difference between your"
					+ " input and the answer is " + Math.abs(answer - input));
		}while(input != answer);//loops until user gets answer correctly
	}

}
