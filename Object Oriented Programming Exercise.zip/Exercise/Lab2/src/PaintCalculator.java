import java.util.Scanner;
public class PaintCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		double length, width, height;
		//getting values
		System.out.println("Please input the length of the room: ");
		length = input.nextDouble();
		System.out.println("Please input the width of the room: ");
		width = input.nextDouble();
		System.out.println("Please input the height of the room: ");
		height = input.nextDouble();
		
		double price = paintCalculator(length, width, height);
		//final output
		System.out.println("Therefore, $" + price + " is the final price.");
	}
	public static double paintCalculator(double length, double width, double height) {
		//finding wall area and price
		double wallArea = 2 *((width * height) + (length * height));
		System.out.println(numberOfGallons(wallArea) + " gallons of paint is needed");
		return 32 * numberOfGallons(wallArea);
	}
	public static double numberOfGallons(double wallArea) {
		return wallArea / 350;
	}
}
