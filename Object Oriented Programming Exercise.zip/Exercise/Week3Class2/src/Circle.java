
public class Circle {

	double radius = 1;
	public Circle() {
	}

	public Circle(double newRadius){
		radius = newRadius;
	}
	
	public Circle(double r1, boolean b) {
		if(b) radius = r1;
	}
	
	double getArea() {
		return radius * radius * 3.14159;
	}
}
