
public class AnimalMain {

	public static void main(String[] args) {
		String animal = "Capybara";
		Animal John = new Animal(animal);
		System.out.println("The animal -> " + John.type + " is running and plays with the ball" );
		John.getName("John");
		John.getHeight(0.6);
		John.getLength(1.3);
		John.getMass(79);
		System.out.println(John.name+ " is a " + John.type + " weighing " + John.mass + 
				" kilos and with a " + "length and height of " + John.length + 
				" " + John.height + " meters respectivily");
	}

}
