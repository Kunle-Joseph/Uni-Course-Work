
public class Animal {
	int age = 1;
	String type, name;
	double mass, height, length;
	public Animal() {
		
	}
	
	public Animal(int newAge)//call with age 
	{
		age = newAge;
	}
	public Animal(String animal) {
		type = animal;
	}
	
	void getMass(double Mass) {
		mass = Mass;
	}
	
	void getHeight(double Height) { height = Height;}

	void getLength(double Length) {
		length = Length;
	}
	
	void getName(String Name) {
		name = Name;
	}
}
