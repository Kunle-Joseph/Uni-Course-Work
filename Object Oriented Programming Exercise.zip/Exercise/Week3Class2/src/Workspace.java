
public class Workspace {

	public static void main(String[] args) {
	}

}
