
public abstract class Building {
	protected int stories;
	protected String name;
	
	public abstract void setStory();
	public abstract void setName();
	
	public void showInfo() {
		System.out.println("The " + name + " is a " + stories + " story building");
	}
}
