import javax.swing.*;
public abstract class Insurance {
	protected String type;
	protected double cost;
	
	public Insurance(String t) {
		type = t;
	}
	
	public String getType() {
		return type;
	}
	public double getCost() {
		return cost;
	}
	
	public abstract void setCost();
	public abstract void display();
}
