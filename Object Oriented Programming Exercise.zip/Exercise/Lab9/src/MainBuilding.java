
public class MainBuilding extends UniversityBuilding {
	protected String course;
	
	public MainBuilding(String c) {
		super("Beige");
		setStory();
		course = c;
		setName();
	}
	
	public void setStory() {
		stories = 5;
	}
	
	public void setName() {
		name = course + " Building";
	}
	
	public String getCourse() {
		return course;
	}
	
	public void showInfo() {
		System.out.println("The " + name + " is a " + stories + " story building"
				+ " where " + course + " is studied");
	}
}
