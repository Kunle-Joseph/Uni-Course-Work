
public class EuropaBuilding extends UniversityBuilding {
	private double rooms;
	static int id;
	
	public EuropaBuilding(double r) {
		super("Cream");
		setStory();
		setRooms(r);
		id++;
		setName();
	}
	
	public void setStory() {
		stories = 3;
	}
	
	public void setName() {
		name = "Europa Building " + id;
	}
	
	public void setRooms(double r) {
		rooms = r;
	}
	
	public double getRooms() {
		return rooms;
	}
	
	public double roomsPerFloor() {
		return rooms/stories;
	}
	
	public void showInfo() {
		System.out.println("The " + name + " is a " + stories + " story building"
				+ " with " + String.format("%.2f", roomsPerFloor()) + " rooms per floor");
	}
}
