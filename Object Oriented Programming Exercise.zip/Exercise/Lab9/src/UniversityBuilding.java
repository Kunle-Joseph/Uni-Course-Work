
public class UniversityBuilding extends Building {
	protected String color;
	
	public UniversityBuilding(String c) {
		color = c;
	}

	public void setStory() {
		stories = 4;
	}

	public void setName() {
		name = "University Building";
	}

	public String getColor() {
		return color;
	}
	
	public void setColor(String c) {
		color = c;
	}
	
	public void showInfo() {
		System.out.println("The " + name + " is a " + stories + " story building");
	}
}
