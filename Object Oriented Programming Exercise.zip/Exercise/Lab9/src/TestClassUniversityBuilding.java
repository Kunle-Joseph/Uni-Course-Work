
public class TestClassUniversityBuilding {

	public static void main(String[] args) {
		UniversityBuilding[] building = {
				new MainBuilding("Medicine"),
				new MainBuilding("Art"),
				new MainBuilding("Architecture"),
				new MainBuilding("Computer Science"),
				new MainBuilding("Business"),
				new EuropaBuilding(10),
				new EuropaBuilding(12),
				new EuropaBuilding(11),
				new EuropaBuilding(18),
				new EuropaBuilding(8),
		};
		for(int i = 0; i < building.length; i++) {
			building[i].showInfo();
		}
	}

}
