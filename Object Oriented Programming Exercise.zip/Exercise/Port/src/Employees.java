import java.util.Scanner;
public class Employees {
	int age; 
	String name, assignment, ID;
	
	public Employees() {
		
	}
	
	public Employees(String Name) {//defines employees name
		name = Name;
	}
	
	public Employees(String Name, String id) {//defines employees name and ID
		name = Name;
		ID = id;
	}
	
	public Employees(String Name, int Age) {//defines employees name and age
		name = Name;
		age = Age;
	}
	
	void showInfo() {
		System.out.println("");
		System.out.println("Employee Name: " + name);
		System.out.println("Employee ID: " + ID);
		System.out.println("Employee Age: " + age);
		System.out.println("Employee Assignment: " + assignment);
		System.out.println("");
	}
	
	boolean checkID() {
		if(ID.length() != 5) return false;
		return true;
	}
	
}
