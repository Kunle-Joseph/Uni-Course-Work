import java.util.Scanner;
public class PortMain { 

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Port Joseph = new Port("Joseph");
		Ships Titanic = new Ships("Titanic");
		Titanic.volume = 99;
		Employees John = new Employees("John Doe");
		Joseph.dockShip(Titanic);
		John.age = 41;
		Joseph.assignWorker(John);
		John.ID = "1245";

		System.out.println(John.checkID());
		Joseph.showInfo();
		John.showInfo();
		Titanic.showInfo();
	}

}
