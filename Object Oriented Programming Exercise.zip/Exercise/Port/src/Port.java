import java.util.Scanner;
public class Port {
	String name;
	double capacity = 100;
	//number of employees working in these sections
	int Docks = 0, Equipment = 0, Connections = 0, Cargo = 0; 
	int shipsDocked = 0, employed = 0;
	public Port() {
		
	}
	public Port(String Name) {
		name = Name;
	}
	void dockShip(Ships  x) {
		capacity -= x.volume;
		if (capacity >= 0) {
			shipsDocked++;
			x.docked = true;
		}
		else capacity += x.volume;
	}
	void removeShip (Ships x) {
		capacity += x.volume;
		shipsDocked--;
		x.docked = false;
	}
	void assignWorker(Employees y) {
		Scanner in = new Scanner(System.in);
		boolean check = true;
		do {
			System.out.println("1. Docks");
			System.out.println("2. Equipment");
			System.out.println("3. Connections");
			System.out.println("4. Cargo");
			
			int reply = in.nextInt();
			switch(reply) {
			case 1: Docks++;
					employed++;
					y.assignment = "Docks";
					check = false;
					break;
			case 2: Equipment++;
					y.assignment = "Equipment";
					check = false; employed++;
					break;
			case 3: Connections++;
					y.assignment = "Connections";
					check = false; employed++;
					break;
			case 4: Cargo++;
					y.assignment = "Cargo";
					check = false; employed++;
					break;
			default: System.out.println("Invalid Input!!!!");
					break;
			}
		}while(check);
	}
	
	void unassignWorker(Employees y) {
		employed--;
		switch(y.assignment) {
			case "Docks":Docks--;
					  	 break;
			case "Cargo":Cargo--;
			  			 break;
			case "Connections":Connections--;
 							   break;
			case "Equipment":Equipment--;
 			 				 break;
		}
	}

	void showInfo() {
		System.out.println("");
		System.out.println("Port name: " + name);
		System.out.println("Ships docked: " + shipsDocked );
		System.out.println("Employees hired: " + employed);
		System.out.println("Capacity: " + capacity);
		System.out.println("");
	}
}
