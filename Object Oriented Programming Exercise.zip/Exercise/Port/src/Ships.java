 
public class Ships {
	double volume;
	String name;
	boolean docked;
	
	public Ships() {
		
	}
	
	public Ships(String Name) {
		name = Name;
	}
	
	void showInfo() {
		System.out.println("");
		System.out.println("Ship name: " + name);
		System.out.println("Volume: " + volume);
		System.out.println("Is docked: " + docked);
		System.out.println("");
	}
}
