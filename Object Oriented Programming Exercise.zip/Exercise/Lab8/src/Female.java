//Exercise 3
public class Female extends Child {
	Female(String name, int age) {
		super(name, "Female");
		setAge(age);
	}
	
	void setAge(int age) {
		super.age = age;
	}
	
	void display() {
		System.out.println(this.name + " is a " + this.age + " year old "
			+ this.gender);
	}
}
