
public abstract class GeometricFigure2 implements SidedObject {
	double height, width, area;
	String type;
	
	GeometricFigure2(double height, double width, String type){
		this.height = height;
		this.width = width;
		this.type = type;
	}
	
	abstract void findArea();
}
