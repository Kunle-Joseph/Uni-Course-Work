
public class Square2 extends GeometricFigure2{
	Square2(double height, double width) {
		super(height, width, "Square" );
		findArea();
	}

	@Override
	void findArea() {
		this.area = this.height * this.width;
	}

	@Override
	public void printSides() {
		System.out.println("Has 4 sides");
	}
}
