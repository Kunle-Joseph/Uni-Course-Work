//Exercise 4
public abstract class GeometricFigure {
	double height, width, area;
	String type;
	
	GeometricFigure(double height, double width, String type){
		this.height = height;
		this.width = width;
		this.type = type;
	}
	
	abstract void findArea();
}
