
public interface SidedObject {
	abstract void printSides();
}
