//Exercise 3
public class UseChildren {

	public static void main(String[] args) {
		Child Jane = new Female("Jane", 14);
		Child John = new Male("John", 10);
		Jane.display();
		John.display();
	}

}
