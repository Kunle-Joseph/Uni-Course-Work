
public class Triangle2 extends GeometricFigure2{
	Triangle2(double height, double width) {
		super(height, width, "Triangle" );
		findArea();
	}
	
	@Override
	void findArea() {
		this.area = .5 * this.height * this.width;
	}

	@Override
	public void printSides() {
		System.out.println("Has 3 sides");
	}
}
