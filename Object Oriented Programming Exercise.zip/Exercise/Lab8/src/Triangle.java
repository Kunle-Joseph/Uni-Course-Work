//Exercise 4
public class Triangle extends GeometricFigure {

	Triangle(double height, double width) {
		super(height, width, "Triangle" );
		findArea();
	}
	
	@Override
	void findArea() {
		this.area = .5 * this.height * this.width;
	}
}
