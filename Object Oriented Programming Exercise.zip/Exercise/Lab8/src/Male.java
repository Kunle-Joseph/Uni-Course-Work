//Exercise 3
public class Male extends Child {
	Male(String name, int age) {
		super(name, "Male");
		setAge(age);
	}

	void setAge(int age) {
		super.age = age;
	}

	void display() {
		System.out.println(this.name + " is a " + this.age + " year old "
				+ this.gender);
	}
}
