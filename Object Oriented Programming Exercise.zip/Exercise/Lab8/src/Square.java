//Exercise 4
public class Square extends GeometricFigure {

	Square(double height, double width) {
		super(height, width, "Square" );
		findArea();
	}

	@Override
	void findArea() {
		this.area = this.height * this.width;
	}

}
