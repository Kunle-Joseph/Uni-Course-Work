
public class UseGeometric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GeometricFigure square = new Square(1.2, 4);
		GeometricFigure triangle = new Triangle(3.5, 2.9);
		
		System.out.println(square.type + " area: " + square.area);
		System.out.println(triangle.type + " area: " + triangle.area);
	}

}
