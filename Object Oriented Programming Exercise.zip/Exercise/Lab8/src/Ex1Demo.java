//Exercise 1
public class Ex1Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ex1b test = new Ex1a();
		test.display();
	}

}
