
public interface Ex1b {
	boolean correct = true;
	int number = 1;
	
	void display();
}
