
public class UseGeometry2 {

	public static void main(String[] args) {
		GeometricFigure2 square = new Square2(1.2, 4);
		GeometricFigure2 triangle = new Triangle2(3.5, 2.9);
		
		System.out.println(square.type + " area: " + square.area);
		square.printSides();
		System.out.println(triangle.type + " area: " + triangle.area);
		triangle.printSides();
	}

}
