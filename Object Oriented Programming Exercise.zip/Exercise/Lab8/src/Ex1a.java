
public class Ex1a implements Ex1b {
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println(number);
	}
	
}
