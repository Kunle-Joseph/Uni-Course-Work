//Exercise 3
public abstract class Child {
	String name, gender;
	int age;
	abstract void setAge(int age);
	abstract void display();
	
	Child(String name, String gender){
		this.name = name;
		this.gender = gender;
	}
	
}
