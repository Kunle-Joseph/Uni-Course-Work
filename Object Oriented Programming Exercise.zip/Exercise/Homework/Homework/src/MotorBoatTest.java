
public class MotorBoatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MotorBoat A = new MotorBoat(1200, 25.5, 1);
		A.addFuel(1300);
		A.addFuel(1);
		A.setSpeed(30);
		System.out.println("Initial fuel amount: " + A.getAmount());
		A.operateBoat(8.9, 15);
		System.out.println("Boat travelled an arbitrary distance of: " + 
				A.getDistance());
		System.out.println("Remaining fuel since last usage: " + A.getAmount());
	}

}
