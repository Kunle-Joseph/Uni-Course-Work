/**
 * 
 */
/**
 * @author HP
 *
 */
module Lab12 {
}