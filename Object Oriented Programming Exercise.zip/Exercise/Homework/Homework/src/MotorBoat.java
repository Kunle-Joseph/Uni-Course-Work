//Exercise 2
public class MotorBoat {
	private double capacity, amount, maxSpeed, currentSpeed,
		efficiency, distance;
	public MotorBoat(double capacity, double maxSpeed, double efficiency) {
		this.capacity = capacity;
		this.maxSpeed = maxSpeed;
		this.efficiency = efficiency;
	}
	public void setSpeed(double speed) {
		if(speed <= maxSpeed) {
			this.currentSpeed = speed;
		}
		else System.out.println("Input above maximum speed");
	}
	
	public void addFuel(double added) {
		if(amount < capacity) {
			this.amount += added;
			if(amount >= capacity) {
				amount = capacity;
				System.out.println("Some wasted fuel:( ");
			}
		}
		else System.out.println("Full tank!");
	}
	
	public double getAmount() {
		return amount;
	}
	public double getDistance() {
		return distance;
	}
	public void operateBoat(double s, double t) {
		double time = t;
		this.currentSpeed = s;
		double amountUsed  = efficiency * (currentSpeed * currentSpeed) * time;
		double tempAmount = amount;
		if(amountUsed > amount) {
			for(int i = 1; i <= time; i++) {
				tempAmount -= efficiency * (currentSpeed * currentSpeed);
				if (tempAmount <= 0) {
					time = i;
					break;
				}
			}
			this.amount = 0;
		}
		else this.amount -= amountUsed;
		this.distance = currentSpeed * time;
	}
	public void operateBoat(double t) {
		double time = t;
		double amountUsed  = efficiency * (currentSpeed * currentSpeed) * time;
		double tempAmount = amount;
		if(amountUsed > amount) {
			for(int i = 1; i <= time; i++) {
				tempAmount -= efficiency * (currentSpeed * currentSpeed);
				if (tempAmount <= 0) {
					time = i;
					break;
				}
			}
			this.amount = 0;
		}
		else this.amount -= amountUsed;
		this.distance = currentSpeed * time;
	}
}
