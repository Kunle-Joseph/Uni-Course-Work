//Exercise 1
public class Animal {
	private boolean gender, twoLegs, fourLegs;
	private String color, type;
	// gender: true, male, false, female
	public Animal() {
		gender = false;
		twoLegs = true;
		fourLegs =  false;
		color = "black";
		type = "monkey";
	}
	
	public Animal(boolean gender, String color, String type) {
		this.gender = gender;
		this.color= color;
		this.type = type;
	}
	
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setTwoLegs(boolean twoLegs) {
		this.twoLegs = twoLegs;
		this.fourLegs = !twoLegs;
	}
	public void setFourLegs(boolean fourLegs) {
		this.fourLegs = fourLegs;
		this.twoLegs = !fourLegs;
	}
	public boolean showLegs() {
		if(twoLegs) {
			System.out.println("Two legs");
			return twoLegs;	
		}
		System.out.println("Four legs");
		return fourLegs;
	}
	public boolean getTwoLegs() {
		return twoLegs;
	}
	public boolean getFourLegs() {
		return fourLegs;
	}
	public String getColor() {
		return color;
	}
	public String getType() {
		return type;
	}
	public boolean getGender() {
		return gender;
	}
}
