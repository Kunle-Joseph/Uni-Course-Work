//Exercise 1
public class AnimalDemoClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal pigeon = new Animal(true, "grey", "Pigeon");
		Animal monkey = new Animal();
		System.out.println(monkey.getType());
		monkey.showLegs();
		pigeon.setTwoLegs(true);
		pigeon.showLegs();
		pigeon.setGender(false);
		
		if(pigeon.getGender()) System.out.println("Male bird");
		else System.out.println("Female bird");
		
		System.out.println(monkey.getColor());
	}

}
