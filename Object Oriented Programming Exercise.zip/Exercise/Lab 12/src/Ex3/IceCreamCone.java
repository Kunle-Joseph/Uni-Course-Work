package Ex3;

public class IceCreamCone {
	private String flavor;
	private int scoops;
	
	IceCreamCone(String f, int s){
		setScoops(s);
		setFlavor(f);
	}
	
	public String getFlavor() {
		return flavor;
	}
	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}
	public int getScoops() {
		return scoops;
	}
	public void setScoops(int scoops) {
		this.scoops = scoops;
	}
}
