package Ex3;

public class IceCreamConeException extends Exception  {
	public IceCreamConeException(String i, int n){
		super("Flavor: " + i
				+ "\nScoops: " + n);
	}
}
