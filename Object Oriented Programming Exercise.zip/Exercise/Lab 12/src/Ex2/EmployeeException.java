package Ex2;

public class EmployeeException extends Exception {
	public EmployeeException(String s)
	{
		super(s);
	}
}
