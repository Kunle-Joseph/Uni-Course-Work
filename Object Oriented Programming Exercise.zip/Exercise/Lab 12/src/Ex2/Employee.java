package Ex2;
import java.util.*;

public class Employee {
	private double hourlyWage;
	private int idNum;
	
	Employee(double w, int i)throws EmployeeException
	{
		hourlyWage = w;
		idNum = i;
		
		if (w < 6 || w > 50) {
			throw (new EmployeeException("ID: " + i
						+ "\nHourly Wage: " + w));
		}
	}

	public Employee() {
	}

	public double getHourlyWage() {
		return hourlyWage;
	}
	
	public String toString() {
		return "ID: " + idNum;
	}
}
