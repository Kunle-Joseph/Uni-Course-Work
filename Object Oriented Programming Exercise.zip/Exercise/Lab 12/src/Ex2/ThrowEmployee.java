package Ex2;

public class ThrowEmployee {

	public static void main(String[] args) {
		Employee[] list = new Employee[3];
		double wage[] = { 4, 25, 65};
		int number[] = {1, 2, 3};
		for(int i = 0; i < list.length; i++)
			list[i] = new Employee();
		for(int i = 0; i < list.length; i++) {
			try {
				list[i] = new Employee(wage[i], number[i]);
			} catch (EmployeeException e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
		System.out.println("Employees in pay range");
		for(int i = 0; i < list.length; i++) {
			if(!(list[i].getHourlyWage() < 6 || list[i].getHourlyWage() > 50))
				System.out.println(list[i].toString());
		}
	}

}
