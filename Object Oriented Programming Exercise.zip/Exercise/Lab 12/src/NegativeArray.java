import javax.swing.*;
public class NegativeArray {

	public static void main(String[] args) throws NumberFormatException, ArrayIndexOutOfBoundsException {
		// TODO Auto-generated method stub
		char c;
		int a[];
		int sz;
		String size;
		try
		{
		size = JOptionPane.showInputDialog(null,
		"Please enter a value for the array size");
		sz = Integer.parseInt(size);
		a = new int[sz];
		JOptionPane.showMessageDialog(null,
		"Successful creation of array of size " + sz);
		}
		catch(Exception e)
		{
		JOptionPane.showMessageDialog(null,
		"Error caught: " + e.getMessage());
		}
	}

}
