//Olakunle Joseph, Week 6 question 3
#include <iostream>
using namespace std;
const int MAX = 100;

class birthdayRec {
	public:
		int day, month;
};
typedef char str[100];
class contactRec {
	public:
		str name, telephone;
		birthdayRec birthday;
};

void readContact(contactRec&);
void deleteContact(contactRec[], int&, str);
void displayContact(contactRec[], int);

int main()
{
	char ch;
	str c;
	contactRec x[MAX];
	int size = 0, reply;

	do {
		cout << "Type 1 to add a contact\n";
		cout << "Type 2 to delete a contact\n";
		cout << "Type 3 to display all contacts\n";
		cout << "Type 4 to exit\n";

		do {
			cout << "Your choice: ";
			cin >> reply;
			while (ch = getchar() != '\n');
			if (reply < 1 || reply > 4)
				cout << "Invalid choice\n";
		} while (reply < 1 || reply > 4);

		switch (reply)
		{
		case 1:
			cout << "Please put in your name, telephone number and birthday (format: day/month)\n";
			readContact(x[size++]);
			break;
		case 2:
			cout << "Enter a contact name: ";
			cin >> c;
			deleteContact(x, size, c);
			break; 
		case 3:
			displayContact(x, size);
			break;
		default:
			break;
		}
	} while (reply != 4);
}

void readContact(contactRec& x)
{
	cout << "Name: ";
	gets_s(x.name);
	cout << "Telephone: ";
	gets_s(x.telephone);
	cout << "Birthday, day: ";
	cin >> x.birthday.day;
	cout << "Birthday, month: ";
	cin >> x.birthday.month;
	cout << "\n\n";
}

void deleteContact(contactRec A[], int& n, str name)
{
	int pos = -1;
	for (int i = 0; i < n; i++) {
		if (!strcmp(A[i].name, name)) {
			pos = i;
			break;
		}
	}
	if (pos == -1)
		cout << "Contact \*" << name << "\* does not exist\n";
	else {
		n--;
		for (int i = pos; i < n; i++)
			A[i] = A[i + 1];
		cout << "Contact \*" << name << "\* is deleted\n";
	}
}

void displayContact(contactRec A[], int n)
{
	for (int i = 0; i < n; i++) {
		cout << "Contact " << i + 1 << ": ";
		cout << A[i].name << " DOB: " << A[i].birthday.day << '/' << A[i].birthday.month << " Telephone: "
			<< A[i].telephone << "\n\n";
	}
}
