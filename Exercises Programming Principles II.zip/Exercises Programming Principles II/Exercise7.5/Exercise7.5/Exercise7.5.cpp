// Exercise7.5.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <iostream>
using namespace std;

int digitSeven(int n) {
	int total = 0;
    while (n != 0){
        int curr_digit = n % 10;
        if (curr_digit == 7) total++;
        n /= 10;
    }
    return total;
}

int main()
{
	int arr[10] = { 564, 57374, 987, 23, 17772, 2345, 99, 556, 27, 333};
    for (int i = 0; i < 10; i++) {
        if (digitSeven(arr[i]) > 0) {
            cout << arr[i] << " has " << digitSeven(arr[i]) << " seven(s)!\n";
        }
    }
}