#include <iostream>
using namespace std;

int main()
{
	int A[] = { 18,8,12,4,6,14,1,10,9,3,5,2,0,7,16 };
	int length = 0;
	
	for (int i = 0; A[i] >= 0; i++)
		length++;

	cout << "There are " << length << " variables in the array\n";
	cout << "Initial Array: ";
	for (int i = 0; i < length; i++)
		cout << A[i] << " ";
	cout << endl;

	for (int i = 0; i < length; i++) {
		int temp;
		if (i < length - 1) {
			if (A[i] > A[i + 1]) {
				temp = A[i];
				A[i] = A[i + 1];
				A[i + 1] = temp;
				i = -1;
			}
		}
	}

	cout << "Sorted Array: ";
	for (int i = 0; i < length; i++)
		cout << A[i] << " ";
	cout << endl;
}
