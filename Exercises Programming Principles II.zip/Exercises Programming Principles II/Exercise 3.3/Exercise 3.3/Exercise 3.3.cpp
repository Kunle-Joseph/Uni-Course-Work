#include <iostream>
using namespace std;
const int MAX = 100;

int main()
{
	int A[MAX], B[MAX], n;
	
	do {
		cout << "Enter n: ";
		cin >> n;
	} while (n < 1 || n > 100);

	cout << "Enter " << n << " values for array A\n";
	for (int i = 0; i < n; i++)
	{
		cin >> A[i];
	}

	cout << "Enter " << n << " values for array B\n";
	for (int i = 0; i < n; i++)
	{
		cin >> B[i];
	}

	for (int i = 0; i < n; i++) {
		if (A[i] != B[i]) {
			cout << "Arrays NOT Equal\n";
			return 0;
		}
	}

	cout << "Arrays are equal\n";
}