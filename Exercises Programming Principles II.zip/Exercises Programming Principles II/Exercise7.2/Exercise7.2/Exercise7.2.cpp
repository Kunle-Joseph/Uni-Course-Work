// Exercise7.2.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <iostream>
using namespace std;

void mirror(char s[]) {
    int i;
    for (i = 0; s[i] != '\0'; i++);
    for (int j = 0; j < i; j++)
        s[j + i] = s[i - j -1];
    s[2 * i] = '\0';
}

bool Divide(char* s) {
    int i;
    for (i = 0; s[i] != '\0'; i++);
    if (i < 2) return false;
    s[i / 2 - 1] = '\0';
    return true;
}

int main()
{
    char word[100], c;
    int n = 0;
    cout << "Enter a string: ";

    gets_s(word);

    do {
        for (int i = 0; i < n; i++)
            cout << ' ';
        mirror(word);
        cout << word << endl;
        n++;
    } while (Divide(word));
}