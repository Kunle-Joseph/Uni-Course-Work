// Olakunle Joseph, Week 6 question 2
#include <iostream>
using namespace std;
enum DAY { Mon, Tue, Wed, Thurs, Fri, Sat, Sun };

void display(DAY d);
void yesterday(DAY& d);
DAY tomorrow(DAY d);
DAY lapse(DAY d, int);
bool weekend(DAY d);

int main()
{
	int n;
	DAY d;
	cout << "Enter day (0 for Mon, 1 for Tue, etc): ";
	do {
		cin >> n;
		if (n < 0 || n > 6) {
			cout << "Invalid Input\n";
			cout << "Enter day: ";
		}
	} while (n < 0 || n > 6);
	d = DAY(n);
	cout << "Today is a ";  display(d);
	DAY y = tomorrow(d);
	cout << "Tomorrow us a ";
	display(y);
	yesterday(d);
	cout << "Yesterday was a ";
	display(d);

}

void display(DAY d){
	switch (d) {
	case Mon:
		cout << "Monday\n";
		break;
	case Tue:
		cout << "Tuesday\n";
		break;
	case Wed:
		cout << "Wednesday\n";
		break;
	case Thurs:
		cout << "Thursday\n";
		break;
	case Fri:
		cout << "Friday\n";
		break;
	case Sat:
		cout << "Saturday\n";
		break;
	case Sun:
		cout << "Sunday\n";
		break;
	}
}

void yesterday(DAY& d)
{
	d = DAY((d - 1 + 7) % 7);
}

DAY tomorrow(DAY d)
{
	return DAY((d + 1 ) % 7);
}

DAY lapse(DAY d, int n)
{
	return DAY((d + n) % 7);
}

bool weekend(DAY d)
{
	if (d == Sat || d == Sun)
		return true;
	return false;
}
