// Exercise7.4.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <iostream>
using namespace std;

bool repititionCheck(const  int A[], int i) {
	int X[10];
	for (int j = 0; j < i; j++)
		X[j] = A[j];
	X[i] = A[i];
	for (int j = 0; j < i; j++) {
		if (X[j] == A[i]) {
			return true;
		}
	}
	return false;
}
void displayArray(const int A[]) {
	for (int i = 0; i < 10; i++) {
		cout << i + 1 << ".) " << A[i] << endl;
	}
}


int main()
{
	int arr[10] = {};

	//filling array
	for (int i = 0; i < 10; i++) {
		cout << "Enter number " << i + 1 << ": ";
		cin >> arr[i];
		if (i > 0) {
			if (repititionCheck(arr, i)) {
				do {
					cout << "Repeating value! Try again\n";
					cout << "Enter number " << i + 1 << ": ";
					cin >> arr[i];
				} while (repititionCheck(arr, i));
			}
		}
	}

	cout << "\n\n\n";
	displayArray(arr);
}