// Exercise7.1.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <iostream>
#include <cstring>

using namespace std;

bool isPalindrome(int);
bool isPalindrome(char*);
void onlyLetters(char[]);

int main()
{
    int n, choice;
    char s[100];
    char ch;
    cout << "PALINDROMES!!!\n";
    cout << "1. Words\n";
    cout << "2. Number\n";
    cout << "3. Exit\n";

    do {
        cout << "Your choice: ";
        cin >> choice;

        if (choice == 1) {
            while (ch = getchar() != '\n');
            cout << "Enter a string to check if its a palindrome: ";
            gets_s(s);
            if(isPalindrome(s))
                cout << "Its a palindrome!\n";
            else
                cout << "Its not a palindrome!\n";
        }
        else if (choice == 2) {
            cout << "Enter a number to check for palindrome properties: ";
            cin >> n;

            if (isPalindrome(n))
                cout << endl << n << " is a palindrome!\n";
            else
                cout << endl << n << " is not a palindrome!\n";
        }
        else if (choice == 3) {
            cout << "\nThank you!";
        }
        else
            cout << "Invalid!\n";
    } while (choice < 3 || choice > 3);
    cout << "\nOver";
    
}

bool isPalindrome(int n)
{
    int num, digit, rev = 0;
    num = n;

    do
    {
        digit = num % 10;
        rev = (rev * 10) + digit;
        num = num / 10;
    } while (num != 0);

    return n == rev;
}

bool isPalindrome(char* s) {
    bool p = true;
    int i;
    onlyLetters(s);
    for (i = 0; s[i] != '\0'; i++);
    for (int j = 0; j < i / 2; j++)
        if (s[j] != s[i - 1 - j])
            p = false;
    return p;
}

void onlyLetters(char s[])
{
    int i, j = 0;
    for (i = 0; s[i] != '\0'; i++);
    while (s[j] != '\0') {
        if (s[j] >= 'A' && s[j] <= 'Z') {
            s[j] = s[j] + 'a' - 'A';
            j++;
        }
        else if (s[j] >= 'a'&& s[j] <= 'z') {
            j++;
        }
        else {
            for (int k = j; k < i; k++)
                s[k] = s[k + 1];
            i--;
        }
    }
}
