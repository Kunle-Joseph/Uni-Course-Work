// Polynomial.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Olakunle Joseph, U211N1122
#include <iostream>
#include <cstdlib>
const int SIZE = 10;
using namespace std;

//Function definitions
void enterData(double polynomial[SIZE], double &coefficient, int& power, bool& check)
{
    char c;
    bool nextPower = false;
    bool negative = false;

    while (c = cin.get(), c != '\n')
    {
        if (c == '+' || c == '-') {
            nextPower = false;
            if (c == '-')//for the case of subtraction
                negative = true;
            else
                negative = false;
            check = false;
        }
        else if (c == 'x' || c == 'X') {
            nextPower = true;
            check = false;
        }
        else if (c >= '0' && c <= '9')
        {
            cin.unget();
            if (nextPower)
            {
                cin >> power;

                if (negative)
                    polynomial[power] = -coefficient;
                else
                    polynomial[power] = coefficient;
                nextPower = false;
            }
            else
                cin >> coefficient;
            check = false;
        }
        else //prevents invaldid polynmials
            check = true;
        
    }
}

// main code
int main()
{
    double polynomial1[SIZE] = {};
    double polynomial2[SIZE] = {};
    double polynomial3[SIZE] = {};
    double coefficient = 0;
    int power = 0;
    bool nextPower = false;
    bool check = true;
    
    while (check){
        cout << "Please enter a polynomial: ";
        enterData(polynomial1, coefficient, power, check);
        if (check)
            cout << "Invalid Input!\n";
    }

    check = true;
    while (check){
        cout << "Please enter another polynomial: ";
        enterData(polynomial2, coefficient, power, check);
        if (check)//prevents invaldid polynmials
            cout << "Invalid Input!\n";
    }

    cout << "P1:\n";
    for (int i = 9; i >= 0; i--)
        if (polynomial1[i] != 0)
        {
            cout << "coefficient = " << polynomial1[i] << "   power = " << i << endl;
        }

    cout << "P2:\n";
    for (int i = 9; i >= 0; i--)
        if (polynomial2[i] != 0)
        {
            cout << "coefficient = " << polynomial2[i] << "   power = " << i << endl;
        }

    for (int i = 9; i >= 0; i--){
            polynomial3[i] = polynomial1[i] + polynomial2[i];
        }

    cout << "P3:\n";
    for (int i = 9; i >= 0; i--)
        if (polynomial3[i] != 0)
        {
            cout << "coefficient = " << polynomial3[i] << "   power = " << i << endl;
        }

    cout << "Final polynomial is: ";
    for (int i = 0; i <= 9; i++)
        if (polynomial3[i] != 0)
        {
            cout  << polynomial3[i] << "x" << i << "+";
        }
    cout << "\b";
    return 0;
}