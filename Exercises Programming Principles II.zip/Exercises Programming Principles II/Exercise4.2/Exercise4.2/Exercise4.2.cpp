// Olakunle Joseph, Exercise 4 question 2
#include <iostream>
#include <iomanip>
using namespace std;
const int MAX = 4;
const int ODD_MAX = 255;

int main()
{
	int Arr[MAX][MAX];
	int i, j;

	// filling the magic sqaure
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 4; j++) {
			cout << "Please enter a value for position for " << i + 1 << j + 1 << ": ";
			cin >> Arr[i][j];
		}
	}

	int sum = 0;
	// checking first row
	for (i = 0, j = 0; j < 4; j++)
		sum += Arr[i][j];

	const int check = sum;
	sum = 0;

	//checking second row
	for (i = 1, j = 0; j < 4; j++)
		sum += Arr[i][j];
	if (sum != check) {
		cout << "NOT A MAGIC SQUARE!\n";
		cout << "Second row doesnt add up\n";
		return 0;
	}

	sum = 0;

	//checking third row
	for (i = 2, j = 0; j < 4; j++)
		sum += Arr[i][j];
	if (sum != check) {
		cout << "NOT A MAGIC SQUARE!\n";
		cout << "Third row doesnt add up\n";
		return 0;
	}

	sum = 0;

	//checking fourth row
	for (i = 3, j = 0; j < 4; j++)
		sum += Arr[i][j];
	if (sum != check) {
		cout << "NOT A MAGIC SQUARE!\n";
		cout << "Fourth row doesnt add up\n";
		return 0;
	}

	sum = 0;
	//checking first columm
	for (j = 0, i = 0; i < 4; i++)
		sum += Arr[i][j];
	if (sum != check) {
		cout << "NOT A MAGIC SQUARE!\n";
		cout << "First column doesnt add up\n";
		return 0;
	}
	sum = 0;
	//checking second columm
	for (j = 1, i = 0; i < 4; i++)
		sum += Arr[i][j];
	if (sum != check) {
		cout << "NOT A MAGIC SQUARE!\n";
		cout << "Second column doesnt add up\n";
		return 0;
	}
	sum = 0;
	//checking third columm
	for (j = 2, i = 0; i < 4; i++)
		sum += Arr[i][j];
	if (sum != check) {
		cout << "NOT A MAGIC SQUARE!\n";
		cout << "Third column doesnt add up\n";
		return 0;
	}
	sum = 0;
	//checking fourth columm
	for (j = 3, i = 0; i < 4; i++)
		sum += Arr[i][j];
	if (sum != check) {
		cout << "NOT A MAGIC SQUARE!\n";
		cout << "Fourth column doesnt add up\n";
		return 0;
	}

	sum = 0;
	// checking first diagonal
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 4; j++) {
			if (i == j)
				sum += Arr[i][j];
		}
	}
	if (sum != check) {
		cout << "NOT A MAGIC SQUARE!\n";
		cout << "First diagonal doesnt add up\n";
		return 0;
	}

	sum = 0;
	//checking second diagonal
	for (i = 3, j = 0; i >= 0 , j < 4; i--, j++)
		sum += Arr[i][j];
	if (sum != check) {
		cout << "NOT A MAGIC SQUARE!\n";
		cout << "Second diagonal doesnt add up\n";
		return 0;
	}
	
	cout << "It is a magic square!\n";

	// new magic square
	int A[ODD_MAX][ODD_MAX] = {};
	int x;
	do {
		cout << "\nEnter the size(odd numbered) of the new magic sqaure: ";
		cin >> x;

		if (x % 2 == 0)
			cout << "\nInvalid input";
		
	} while ( x % 2 != 1 || x <= 0);

	int row = 0, col = x / 2;
	A[row][col] = 1;

	for (i = 2; i <= x * x; i++) {
		if (A[(row - 1 + x) % x][(col + 1) % x] == 0) {
			row = ((row - 1) + x) % x;
			col = (col + 1) % x;
		}
		else
			row = (row + 1) % x;
		A[row][col] = i;
	}

	for (row = 0; row < x; row++) {
		for (col = 0; col < x; col++)
			cout << setw(6) << A[row][col];
		cout << endl;
	}

	return 0;
}

