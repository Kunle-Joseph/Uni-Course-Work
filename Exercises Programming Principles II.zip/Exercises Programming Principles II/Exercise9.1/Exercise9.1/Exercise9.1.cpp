// Exercise9.1.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <iostream>
using namespace std;

class BMI {
public:
    void readName(string);
    void setInfo(double, double);
    double calculateBMI();
    void display(double) const;
private:
    string name;
    double weight = 0;
    double height = 0;
};

int main()
{
    BMI customer;
    char s[20];
    double w, h;
    cout << "Please input your name: ";
    gets_s(s);
    customer.readName(s);
    cout << "Enter weight: ";
    cin >> w;
    cout << "Enter height: ";
    cin >> h;
    customer.setInfo(w, h);
    double bmi = customer.calculateBMI();
    customer.display(bmi);

    return 0;
}

void BMI::readName(string s)
{
    name = s;
}

void BMI::setInfo(double w, double h)
{
    weight = w;
    height = h;
}

double BMI::calculateBMI()
{
    return weight / pow(height, 2);
}

void BMI::display(double bmi) const
{
    cout << name << " your BMI is " << bmi << endl;
    if (bmi < 18.5)
        cout << "You are underweight" << endl;
    else if (bmi < 24.9)
        cout << "You have healthy weight" << endl;
    else if (bmi < 29.9)
        cout << "You are overweight" << endl;
    else
        cout << "You are OBESE" << endl;
}
