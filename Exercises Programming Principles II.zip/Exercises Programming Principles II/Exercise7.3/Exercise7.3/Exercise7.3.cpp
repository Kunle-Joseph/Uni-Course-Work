// Exercise7.3.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <iostream>
using namespace std;

int addAfter(char str[], char ch1, char ch2) {
    if (ch1 == ch2)
        return 1;
    int i = 0;
    for (i = 0; str[i] != '\0'; i++);
    int count = 0;

    char temp[100];
    int j;
    for (j = 0; str[j] != '\0'; j++)
        temp[j] = str[j];
    temp[j + 1] = '\0';

    for (int j = 0; j < i; j++) {
        if (str[j] == ch1) {
            count++;
            str[j + 1] = 'ch2';
        }
    }
}

int main()
{
    char str[100];
    char ch;
    cout << "Enter a string: ";
    gets_s(str);

    addAfter(str, 'a', '1');
    cout << str;
}