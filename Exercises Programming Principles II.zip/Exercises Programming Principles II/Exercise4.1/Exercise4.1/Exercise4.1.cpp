//Exercise 4 question 1
#include <iostream>
#include <iomanip>
using namespace std;
const int MAX = 10;

int main()
{
    int table[MAX][MAX], i , j, sum = 0;

    for (i = 0; i < 10; i++) {
        table[i][0] = i + 1;
    }
    for (j = 0; j < 10; j++) {
        table[0][j] = j + 1;
    }

    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {
            int x = i + 1, y = j + 1;
            table[i][j] = x * y;
            sum += table[i][j];
        }
    }

    for (i = 0; i < 10; i++) {
        cout << "Row " << i << ":  ";
        for (j = 0; j < 10; j++) {
            cout << setw(4) << table[i][j] << "   ";
        }
        cout << endl;
    }

    cout << endl;
    cout << "Sum is " << sum << "\n\n";

    int div_by_3 = 0;
    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {
            if (table[i][j] % 3 == 0)
                div_by_3++;
        }
    }
    cout << div_by_3 << " numbers are divisible by 3\n\n";

    int sum_row6 = 0;
    for (j = 0; j < 10; j++) 
        sum_row6 += table[6][j];
    cout << sum_row6 << " is the sum of row 6 numbers\n\n";

    int sum_by_col[MAX];
    for (i = 0; i < 10; i++)
        sum_by_col[i] = 0;
    
    for (j = 0; j < 10; j++) {
        for (i = 0; i < 10; i++)
            sum_by_col[j] += table[i][j];
    }

    cout << "Sum by each column are: \n";
    for (i = 0; i < 10; i++)
        cout << "Sum of column " << i << " is: " << sum_by_col[i] << "\n\n";

    int row, num;
    bool cont = true;
    do {
        cout << "Please enter a row\n";
        cin >> row;
        if (row < 1 || row > 10) {
            cout << "Invalid!\n";
            continue;
        }
        row--;
        cout << "Please enter a number to check\n";
        cin >> num;
        for (j = 0; j < 10; j++) {
            if (num == table[row][j]) {
                cout << "Yes there's a " << num << " in this row!\n";
                cont = false;
            }
        }
        if (cont == true)
            cout << "No such number in this row\n\n";
    } while (cont);

    int leftdiagonal = 0, rightdiagonal = 0;
    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {
            if (i == j) {
                leftdiagonal += table[i][j];
            }
        }
    }
    for (i = 9, j = 0; i >= 0, j < 10; i--, j++) {
        rightdiagonal += table[i][j];
    }
    cout << "The sum of the diagonals are " << leftdiagonal << " and " << rightdiagonal << "\n\n";
}
