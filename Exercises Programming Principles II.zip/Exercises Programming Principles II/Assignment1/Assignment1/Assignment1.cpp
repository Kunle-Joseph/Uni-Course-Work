//Olakunle Joseph, Assignment 1, U211N1122
#include <iostream>
using namespace std;
const int MAX = 256;

int main()
{
	cout << "How many elements in set A? ";
	int n; 
	cin >> n;
	int *A;
	A = new int[n];

	int X[MAX];

	int i, j;
	//filling in array A
	for (i = 0; i < n; i++) {
		cout << "A[" << i << "]: ";
		cin >> A[i];
		X[i] = A[i];
		for (j = 0; j < i; j++) {
			if (X[j] == A[i]) {
				do {
					cout << "Try again. A[" << i << "]: ";
					cin >> A[i];
				} while (X[j] == A[i]);
			}
		}
	}

	cout << "How many elements in set B? ";
	int m;
	cin >> m; 
	int* B;
	B = new int[m];
	//filling in array B
	int Y[MAX];
	for (i = 0; i < m; i++) {
		cout << "B[" << i << "]: ";
		cin >> B[i];
		Y[i] = B[i];
		for (j = 0; j < i; j++) {
			if (Y[j] == B[i]) {
				do {
					cout << "Try again. A[" << i << "]: ";
					cin >> B[i];
				} while (Y[j] == B[i]);
			}
		}
	}

	//union array
	int C[MAX];
	for (i = 0; i < n; i++)
		C[i] = A[i];
	for (i = n, j = 0; j < m; i++, j++)
		C[i] = B[j];

	cout << "The union of Arrays A and B is: {";
	for (i = 0; i < (n + m); i++) 
		cout << " " << C[i] << ",";
	cout << "\b }\n\n";

	//intersection array
	int D[MAX], x = 0;
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			if (A[i] == B[j]) {
				D[x] = A[i];
				x++;
			}
		}
	}
	cout << "The intersection of Arrays A and B is: {";
	for (i = 0; i < x; i++)
		cout << " " << D[i] << ",";
	cout << "\b }\n\n";

	if (n >= m) //if set A is larger
	{
		//A-B array
		int E[MAX];
		x = 0;
		int k;
		for (i = 0; i < n; i++) {
			for (j = 0; j < m; j++) {
				if (B[j] == A[i])
					break;
			}
			if (j == m) {
				for (k = 0; k < x; k++) {
					if (E[k] == A[i])
						break;
				}
				if (k == x) {
					E[x] = A[i];
					x++;
				}
			}

		}

		cout << "A - B: {";
		for (i = 0; i < x; i++)
			cout << " " << E[i] << ",";
		cout << "\b }\n\n";
	}
	else if (m > n) // set B is larger
	{
		//B-A array
		int E[MAX];
		x = 0;
		int k;
		for (i = 0; i < m; i++) {
			for (j = 0; j < n; j++) {
				if (A[j] == B[i])
					break;
			}
			if (j == n) {
				for (k = 0; k < x; k++) {
					if (E[k] == B[i])
						break;
				}
				if (k == x) {
					E[x] = B[i];
					x++;
				}
			}

		}

		cout << "B - A: {";
		for (i = 0; i < x; i++)
			cout << " " << E[i] << ",";
		cout << "\b }\n\n";
	}
}
