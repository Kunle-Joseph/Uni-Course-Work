#include <iostream>
using namespace std;
const int MAX = 100;

//Exercise 2, question 3

int main()
{
    int Exam[MAX], grade[5], n, mark, avg, sum = 0;

    for (int i = 0; i < 5; i++)
        grade[i] = 0;

    cout << "Enter the number of students in the class: ";
    cin >> n;

    cout << "Enter each students mark\n";
    for (int i = 0; i < n; i++)
        cin >> Exam[i];
    
    for (int i = 0; i < n; i++) {
        sum += Exam[i];
        if (Exam[i] >= 90)grade[0]++;
        else if (Exam[i] >= 80)grade[1]++;
        else if (Exam[i] >= 70)grade[2]++;
        else if (Exam[i] >= 60)grade[3]++;
        else grade[4]++;
    }

    avg = sum / n;

    cout << "The class average is " << avg << endl;
    cout << "There are: \n";

    for (int i = 0; i < 5; i++) {
        if (i == 0) {
            cout << grade[i] << " As\n";
        }
        else if (i == 1) {
            cout << grade[i] << " Bs\n";
        }
        else if (i == 2) {
            cout << grade[i] << " Cs\n";
        }
        else if (i == 3) {
            cout << grade[i] << " Ds\n";
        }
        else if (i == 4) {
            cout << grade[i] << " Fs\n";
        }
    }
}
