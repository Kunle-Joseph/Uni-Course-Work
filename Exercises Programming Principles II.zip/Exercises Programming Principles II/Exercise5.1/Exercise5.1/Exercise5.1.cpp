// Week 5 question 1, 2, 3
#include <iostream>
#include <cstring>
using namespace std;
const int MAX = 100;

int main()
{
	char s1[MAX], s2[MAX];
	cout << "Enter a string: ";
	gets_s(s1);
	int i = 0;
	//question 1
	while (s1[i] != '\0') {
		s2[i] = s1[i];
		i++;
	}
	s2[i] = '\0';
	cout << s2 << endl;

	//question 2
	int length = 0;
	for (; s1[length] != '\0'; length++);
	cout << "\nThe length of " << s1 << " is: " << length << endl;

	//question 3
	i = 0;
	while (i < length) {
		cout << s1[length - i - 1];
		i++;
	}
	cout << s1 << endl;
}
