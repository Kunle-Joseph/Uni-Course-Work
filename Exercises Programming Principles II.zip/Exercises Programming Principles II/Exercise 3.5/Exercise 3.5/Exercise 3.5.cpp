#include <iostream>
#include <ctime>
#include <cstdlib>
#include <math.h>
using namespace std;
const int MAX_SIZE = 500;

int main()
{
	srand(time(NULL));
	double A[MAX_SIZE], B[MAX_SIZE], sum = 0;

	for (int i = 0; i < MAX_SIZE; i++) {
		A[i] = rand() % 1001;
		A[i] /= 1000;
		sum += A[i];
	}
	
	double mean = sum / 500;
	cout << "A.) The mean is " << mean << endl;

	for (int i = 0; i < MAX_SIZE; i++) {
		
		if (abs(mean - A[i]) < 0.05) {
			cout << A[i] << endl;
		}
	}

	double s = sqrt(((sum - mean) * (sum - mean)) / 500);
	cout << "The standard deviation is " << s << endl;
}
