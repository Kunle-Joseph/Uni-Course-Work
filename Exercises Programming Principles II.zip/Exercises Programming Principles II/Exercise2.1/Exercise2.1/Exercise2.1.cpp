#include <iostream>
using namespace std;
const int MAX = 100;
//exercise 2 question 2
int main()
{
	int Nums[MAX];

	int n;
	bool loop = true;

	while (loop) {
		cout << "Enter n: ";
		cin >> n;

		if (n <= 100 && n >= 1)
			loop = false;
	}

	cout << "Enter " << n << " Values\n";

	for (int i = 0; i < n; i++) {
		cin >> Nums[i];
	}

	for (int i = 0; i < n; i++)
		cout << Nums[i] << "  ";

	for (int i = 0; i < n; i++) {
		if (i > 0) {
			if (Nums[i - 1] > Nums[i]) {
				cout << "\nArray is NOT sorted";
				return 0;
			}
		}
	}

	cout << "\nArray is sorted";
}