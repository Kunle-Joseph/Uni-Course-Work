// TicTacToe.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <iostream>
using namespace std;
const int SIZE = 3;

class TicTacToe {
public:
    TicTacToe();//constructor
    bool PlayMove(int Player, int row, int col);
    int Winner()const;
    bool GameOver()const;
    void DisplayBoard()const;
private:
    int NoOfMoves;
    int Board[SIZE][SIZE];
};

int main()
{
    cout << "Hello, this is a game of TICTACTOE!\n";

    TicTacToe Game;
    int row, col;
    bool check;

    do {
        Game.DisplayBoard();
        for (int i = 1; i < 3; i++) {//game phase
            do {
                cout << "Player " << i << ", please enter a row(1 - 3): ";
                cin >> row;
                cout << "Player " << i << ", please enter a column(1 - 3): ";
                cin >> col;

                check = Game.PlayMove(i, row - 1, col - 1);//inputs players move

                if (!check)//stops players from overwriting taken spaces
                    cout << "Invalid Move\n";

            } while (!check);
            Game.DisplayBoard();
            if (Game.GameOver()) {
                if (Game.Winner() == 0)
                    cout << "Its a DRAW!\n";

                else
                    cout << "Player " << Game.Winner() << " has won!\n";

                return 0;
            }
        }
    } while (!Game.GameOver());
    
    return 0;
}

TicTacToe::TicTacToe()
{
    NoOfMoves = 0;
    for (int i = 0; i < SIZE; i++)
        for (int j = 0; j < SIZE; j++)
            Board[i][j] = 0;
}

bool TicTacToe::PlayMove(int Player, int row, int col){
    if (row < 0 || row > 2 || col < 0 || col > 2)
        return false;//prevents error by wrong input
    if (Board[row][col] == 0) {
        Board[row][col] = Player;
        NoOfMoves++;
        return true;
    }
    return false;
}

int TicTacToe::Winner() const
{
    int x, y, z;
    for (int i = 0; i < SIZE; i++) {
        x = Board[i][0];
        y = Board[i][1];
        z = Board[i][2];

        if (x == y && y == z)
            if (x != 0)
                return x;
    }// checking rows

    for (int i = 0; i < SIZE; i++) {
        x = Board[0][i];
        y = Board[1][i];
        z = Board[2][i];

        if (x == y && y == z)
            if (x != 0)
                return x;
    }// checking columns

    {
        x = Board[0][0];
        y = Board[1][1];
        z = Board[2][2];
        if (x == y && y == z)
            if (x != 0)
                return x;
    }//checking diagonal one

    {
        x = Board[0][2];
        y = Board[1][1];
        z = Board[2][0];
        if (x == y && y == z)
            if (x != 0)
                return x;
    }//checking diagonal two

    return 0;
}

bool TicTacToe::GameOver() const
{
    if (Winner() != 0 || NoOfMoves == 9)
        return true;
    return false;
} 

void TicTacToe::DisplayBoard() const
{
    const int HEIGHT = 2, WIDTH = 4, ROWS = 3, COLS = 3;
    system("CLS");
    for (int i = 0; i <= ROWS * HEIGHT; i++)
    {
        for (int j = 0; j <= COLS * WIDTH; j++)
        {
            if (i == 0 && j == 0) cout << char(201);
            else if (i == 0 && j == COLS * WIDTH) cout << char(187);
            else if (i == ROWS * HEIGHT && j == 0) cout << char(200);
            else if (i == ROWS * HEIGHT && j == COLS * WIDTH) cout << char(188);
            else if (i % HEIGHT == 0 && j == 0) cout << char(204);
            else if (i % HEIGHT == 0 && j == COLS * WIDTH) cout << char(185);
            else if (i == 0 && j % WIDTH == 0) cout << char(203);
            else if (i == ROWS * HEIGHT && j % WIDTH == 0) cout << char(202);
            else if (i % HEIGHT == 0 && j % WIDTH == 0) cout << char(206);
            else if (i % HEIGHT == 0) cout << char(205);
            else if (j % WIDTH == 0) cout << char(186);
            else if ((i + HEIGHT / 2) % HEIGHT == 0 && (j + WIDTH / 2) % WIDTH == 0)
                if (Board[i / HEIGHT][j / WIDTH] == 0)
                    cout << ' ';
                else if (Board[i / HEIGHT][j / WIDTH] == 1)
                    cout << 'X';
                else
                    cout << 'O';
            else cout << ' ';
        }
        cout << endl;
    }
}