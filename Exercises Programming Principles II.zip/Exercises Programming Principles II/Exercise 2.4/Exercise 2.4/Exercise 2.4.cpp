#include <iostream>
using namespace std;
#include <stdlib.h>
#include <time.h>
const int MAX = 1000;

//Exercise 2 question 4

int main()
{
    srand(time(0));
    int Arr[MAX], sum = 0, digit[10];

    for (int i = 0; i < 10; i++)
        digit[i] = 0;

    for (int i = 0; i < MAX; i++)
        Arr[i] = 1 + rand() % 50;
    
    for (int i = 0; i < MAX; i++) 
        sum += Arr[i];
        
    for (int i = 0; i < MAX; i++) {
        if (Arr[i] == 10 || Arr[i] == 20 || Arr[i] == 30 || Arr[i] == 40 || Arr[i] == 50)
            digit[0]++;

        else if (Arr[i] < 10)
            digit[Arr[i]]++;

        else if (Arr[i] > 20 && Arr[i] < 30)
            digit[(Arr[i] % 20)]++;

        else if (Arr[i] > 30 && Arr[i] < 40)
            digit[(Arr[i] % 30)]++;

        else if (Arr[i] > 40 && Arr[i] < 50)
            digit[(Arr[i] % 40)]++;

        else if (Arr[i] > 10 && Arr[i] < 20)
            digit[(Arr[i] % 10)]++;
    }

    cout << "The average is " << (sum / MAX) << endl;
    cout << "There are: \n";
    for (int i = 0; i < 10; i++) {
        if (i == 0)
            cout << digit[i] << " 0s\n";
        else if (i == 1)
            cout << digit[i] << " 1s\n";
        else if (i == 2)
            cout << digit[i] << " 2s\n";
        else if (i == 3)
            cout << digit[i] << " 3s\n";
        else if (i == 4)
            cout << digit[i] << " 4s\n";
        else if (i == 5)
            cout << digit[i] << " 5s\n";
        else if (i == 6)
            cout << digit[i] << " 6s\n";
        else if (i == 7)
            cout << digit[i] << " 7s\n";
        else if (i == 8)
            cout << digit[i] << " 8s\n";
        else if (i == 9)
            cout << digit[i] << " 9s\n";
    }
}
