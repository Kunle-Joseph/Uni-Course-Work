#include <iostream>
using namespace std;
const int MAX_SIZE = 10;


int main()
{
	int A[MAX_SIZE], size = 0;
	char reply;

	do {
		cout << "Type \"I\" to insert a number\n";
		cout << " \"D\" to delete a number\n";
		cout << " \"X\" to exit the program\n> ";
		cin >> reply;

		switch (reply)
		{
		case 'I':
		case 'i':
			if (size == MAX_SIZE)
				cout << "Array is full\n";
			else {
				int x, i;
				cout << "Please enter a number: \n";
				cin >> x;

				for (i = size - 1; i >= 0 && A[i] > x; i--)
					A[i + 1] = A[i];
				A[i + 1] = x;
				size++;
			}
			break;

		case 'D':
		case 'd':
			if (size == 0)
				cout << "Array is Empty!\n";
			else {
				int x, position = 0;
				cout << "Enter a number to delete: ";
				cin >> x;

				while (position < size && A[position] != x)
					position++;
				if (position == size)
					cout << "Number doesnt exist!\n";
				else {
					for (position; position < size; position++)
						A[position] = A[position + 1];
					size--;
				}
			}
			break;
		}



		if (reply != 'X' && reply != 'x')
		{
			cout << "The array is : ";
			for (int i = 0; i < size; i++)
				cout << A[i] << " ";
		}
		cout << endl;
	} while (reply != 'X' && reply != 'x');
}