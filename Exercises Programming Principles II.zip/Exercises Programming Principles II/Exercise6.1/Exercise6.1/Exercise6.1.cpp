//Week 6 question 1
#include <iostream>
using namespace std;

void readArray(int [], int n);
int sum(int [], int n);
bool equal(int[], int[], int n);

int main()
{
    int nums[10][5];
    for (int i = 0; i < 10; i++) {
        cout << "Row " << i + 1 <<": \n";
        readArray(nums[i], 5);
    }
    cout << "\n\n";
    for (int i = 0; i < 10; i++) {
        cout << "Sum of row " << i + 1 << ": " << sum(nums[i], 5) << endl;
    }
    cout << "\n\n";
    for (int i = 0; i < 10; i++) {
        for (int j = i + 1; j < 11; j++) {
            if (equal(nums[i], nums[j], 5))
                cout << "Row " << i + 1 << " is the same as row " << j + 1 << endl;
        }
    }
    cout << "\n\n";
    return 0;
}

void readArray(int A[], int n)
{
    cout << "Enter " << n << " values: ";
    for (int i = 0; i < n; i++) {
        cin >> A[i];
    }
}

int sum(int A[], int n)
{
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += A[i];
    }
    return sum;
}

bool equal(int A[], int B[], int n)
{
    bool flag = true;
    for (int i = 0; i < n; i++) {
        if (A[i] != B[i])
            return false;
    }
    return true;
}
