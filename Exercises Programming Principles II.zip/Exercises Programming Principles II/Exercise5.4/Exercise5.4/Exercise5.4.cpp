//Week 5 question 4
#include <iostream>
using namespace std;

int main()
{
    char c;
    int total = 0;
    int count[26] = {};
    cout << "Enter a sentence and end with a full-stop: ";
    while (c = cin.get(), c != '.') {
        c = tolower(c);

        if (c >= 'a' && c <= 'z')
            count[c - 'a']++;
        
        total++;
    }
    cout << "Total characters: " << total << endl;

    for (int i = 0; i < 26; i++) {
        cout << char('A' + i) << ": " << count[i] << endl;
    }
    return 0;
}
