#include <iostream>
using namespace std;
const int MAX = 10;

int main()
{
	float Arr[MAX], sum = 0, avg, position, closest_value, diff1, diff2;

	cout << "Enter 10 float values\n";

	for (int i = 0; i < 10; i++) {
		cin >> Arr[i];
		sum += Arr[i];
	}
	
	avg = sum / 10;
	cout << "The average of the values is " << avg << "!\n";

	for (int i = 0; i < 10; i++) {
		diff1 = abs(Arr[i] - avg);

		if (i == 0) 
			diff2 = diff1;
		
		if (diff1 < diff2 && i > 0) {
			diff2 = diff1;
			position = i + 1;
			closest_value = Arr[i];
		}
	}

	cout << "The values closest to the average is " << closest_value << 
		" and its the position is number " << position;

	return 0;
}
