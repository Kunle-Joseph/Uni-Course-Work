﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practice
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Student firstStudent = new Student("Jon", "Doe", 5,  true);
            Student secondStudent = new Student("Jen", "Doe", 4, false);

            List<Student> students = new List<Student>();
            students.Add(firstStudent);
            students.Add(secondStudent);
            string serialStudent = JsonConvert.SerializeObject(students, Formatting.Indented);

            List<Student> deserialStudent = JsonConvert.DeserializeObject<List<Student>>(serialStudent);
            MessageBox.Show(serialStudent);

        }

        class Student
        {
            public Student(string firstName, string lastName, int age, bool is_act_ive)
            {
                FirstName = firstName;
                LastName = lastName;
                this.age = age;
                this.is_act_ive = is_act_ive;
            }

            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int age { get; set; }    
            public bool is_act_ive { get; set; }
        }
    }
}
