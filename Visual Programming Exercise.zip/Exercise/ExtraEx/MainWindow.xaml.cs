﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExtraEx
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrWhiteSpace(inputBox.Text))
            {
                MessageBox.Show("Plese enter description of your task.", "Missing Task", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            CheckBox check = new CheckBox();
            check.Content= inputBox.Text;

            pendingStack.Children.Add(check);

            UpdateProgress();
        }

        private void UpdateProgress()
        {
            progressBar.Value = doneStack.Children.Count;

            progressBar.Maximum = pendingStack.Children.Count + doneStack.Children.Count;
        }

        private void doneButton_Click(object sender, RoutedEventArgs e)
        {
            for(int i = 0; i < pendingStack.Children.Count; i++)
            {
                CheckBox check = pendingStack.Children[i] as CheckBox;
                if(check.IsChecked == true)
                {
                    TextBlock block = new TextBlock();
                    block.Text= "✓" + check.Content;
                    doneStack.Children.Add(block);
                    pendingStack.Children.RemoveAt(i);
                    --i;
                }
            }

            UpdateProgress();
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            doneStack.Children.Clear();

            UpdateProgress();
        }
    }
}
