﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Final
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Initialising windows to show later
        Tax_Window tax = new Tax_Window();
        BabyName_Window baby = new BabyName_Window();
        Car_Window car = new Car_Window();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void babyButton_Click(object sender, RoutedEventArgs e)
        {
            baby.Show();
        }

        private void taxButton_Click(object sender, RoutedEventArgs e)
        {
            tax.Show();
        }

        private void carButton_Click(object sender, RoutedEventArgs e)
        {
            car.Show();
        }
    }
}
