﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Final
{
    /// <summary>
    /// Interaction logic for Tax_Window.xaml
    /// </summary>
    public partial class Tax_Window : Window
    {
        public Tax_Window()
        {
            InitializeComponent();
        }
        double amount = 0, social, tax, net, socialPercent = 4.56;
        int months;
        const double Tax_Threshold = 19500;


        private void monthlyRadio_Click(object sender, RoutedEventArgs e)
        {
            update();
        }

        private void annualRadio_Click(object sender, RoutedEventArgs e)
        {
            update();

        }

        private void monthCheckBox_Click(object sender, RoutedEventArgs e)
        {
            update();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (monthlyRadio.IsChecked == false && annualRadio.IsChecked == false)
            {
                MessageBox.Show("Please click one of the radio buttons", "Error", MessageBoxButton.OK,
                    MessageBoxImage.Error);
                TextBox.Text = string.Empty;
                return;
            }
            update();
        }

        private void update()
        {
            if (monthCheckBox.IsChecked == true)
                months = 13;
            else
                months = 12;
            if (double.TryParse(TextBox.Text, out amount) == true)
            {
                if (monthlyRadio.IsChecked == true)
                {
                    monthlyGross.Text = amount.ToString("N2");

                    social = (amount * (socialPercent / 100));
                    if ((amount - social) < Tax_Threshold)
                    {
                        tax = 0;
                        notesSocialInsurance.Text = socialPercent.ToString("N2");
                        notesTax.Text = tax.ToString("N2");
                        notesTaxThreshold.Text = Tax_Threshold.ToString("N2");
                    }
                    else 
                    { 
                        tax = (amount - social - Tax_Threshold) * 0.2;
                        notesSocialInsurance.Text = socialPercent.ToString("N2");
                        notesTax.Text = 20.ToString("N2") + "%";
                        notesTaxThreshold.Text = Tax_Threshold.ToString("N2");
                    }
                    net = amount - (social + tax);

                    //monthly
                    monthlyNet.Text = $"$ {net.ToString("N2")}";
                    monthlyTax.Text = $"$ {tax.ToString("N2")}";
                    monthlySocial.Text = $"$ {social.ToString("N2")}";

                    //annual
                    annualGross.Text = $"$ {(amount * months).ToString("N2")}";
                    annualNet.Text = $"$ {(net * months).ToString("N2")}";
                    annualTax.Text = $"$ {(tax * months).ToString("N2")}";
                    annualSocial.Text = $"$ {(social * months).ToString("N2")}";
                }
                else
                {
                    annualGross.Text = amount.ToString("N2");

                    social = (amount * (socialPercent / 100));
                    if ((amount - social) < Tax_Threshold)
                    {
                        tax = 0;
                        notesSocialInsurance.Text = socialPercent.ToString("N2");
                        notesTax.Text = tax.ToString("N2");
                        notesTaxThreshold.Text = Tax_Threshold.ToString("N2");
                    }
                    else
                    {
                        tax = (amount - social - Tax_Threshold) * 0.2;
                        notesSocialInsurance.Text = socialPercent.ToString("N2");
                        notesTax.Text = 20.ToString("N2") + "%";
                        notesTaxThreshold.Text = Tax_Threshold.ToString("N2");
                    }
                    net = amount - (social + tax);

                    //annual
                    annualNet.Text = $"$ {net.ToString("N2")}";
                    annualTax.Text = $"$ {tax.ToString("N2")}";
                    annualSocial.Text = $"$ {social.ToString("N2")}";

                    //monthly
                    monthlyGross.Text = $"$ {(amount / months).ToString("N2")}";
                    monthlyNet.Text = $"$ {(net / months).ToString("N2")}";
                    monthlyTax.Text = $"$ {(tax / months).ToString("N2")}";
                    monthlySocial.Text = $"$ {(social / months).ToString("N2")}";
                }
            }
        }
    }
}
