﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Final
{
    /// <summary>
    /// Interaction logic for BabyName_Window.xaml
    /// </summary>
    public partial class BabyName_Window : Window
    {
        public BabyName_Window()
        {
            InitializeComponent();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void babyRemoveButton_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < babyNameStack.Children.Count; i++)
            {
                CheckBox check = babyNameStack.Children[i] as CheckBox;
                if (check.IsChecked == true)
                {
                    babyNameStack.Children.Remove(check);
                    --i;
                }
            }
        }

        private void babyAddButton_Click(object sender, RoutedEventArgs e)
        {
            if (entryCheck())
            {
                CheckBox check = new CheckBox();
                check.Content = babyNameTextBox.Text;
                babyNameStack.Children.Add(check);
                babyNameTextBox.Text = "";
            }
        }

        private bool entryCheck()
        {
            if (string.IsNullOrEmpty(babyNameTextBox.Text))
            {
                MessageBox.Show("Please fill in the box", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            int i;
            if (int.TryParse(babyNameTextBox.Text, out i) == true)
            {
                MessageBox.Show("Please type in a name", "Error", MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return false;
            }
            return true;
        }
    }
}
