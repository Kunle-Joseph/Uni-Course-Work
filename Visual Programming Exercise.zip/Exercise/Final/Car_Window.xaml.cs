﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Final
{
    /// <summary>
    /// Interaction logic for Car_Window.xaml
    /// </summary>
    public partial class Car_Window : Window
    {
        string color, addOns = "";
        public Car_Window()
        {
            InitializeComponent();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel= true;
            this.Hide();
        }

        private void submitButton_Click(object sender, RoutedEventArgs e)
        {
            if (entryCheck())
            {
                foreach(CheckBox check in checkBoxWrap.Children)
                {
                    if(check.IsChecked == true)
                    {
                        addOns += (string)check.Content + ',';
                    }
                }
                foreach(RadioButton radio in additionalWrap.Children)
                {
                    if(radio.IsChecked== true)
                    {
                        addOns += $" and {(string)radio.Content} insurance.";
                    }
                }
                var response = MessageBox.Show($"Please confirm you would like to order a {color} car with '{carTextBox.Text}'" +
                    $"engraved on the side of the car and the following additional options: \n{addOns}", "Description",
                    MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                if (response == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Thank You");
                }
            }
        }

        private bool entryCheck()
        {
            bool colorCheck = false, addOnCheck = false;
            if (string.IsNullOrEmpty(carTextBox.Text))
            {
                MessageBox.Show("Please fill in the box", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            foreach (RadioButton radio in colorWrap.Children)
            {
                if (radio.IsChecked == true)
                {
                    color = (string)radio.Content;
                    colorCheck = true;
                }
            }
            foreach (RadioButton radio in additionalWrap.Children)
            {
                if (radio.IsChecked == true)
                {
                    addOnCheck = true;
                }
            }
            if (colorCheck && addOnCheck) return true;
            MessageBox.Show("Please choose an option in both sets of radio buttons", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }
    }
}
