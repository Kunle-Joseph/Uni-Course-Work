﻿namespace Homework3_Ex0_UsersAndPanels
{
    internal class User
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Type { get; set; } // Ideally this should be an Enum!

        public override string ToString()
        {
            return $"{FirstName} {LastName} ({Type})";
        }
    }
}