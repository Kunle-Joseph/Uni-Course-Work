﻿using System.Windows;
using System.Windows.Controls;

namespace Homework3_Ex0_UsersAndPanels
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddUserButton_Click(object sender, RoutedEventArgs e)
        {
            User user = GetNewUser();

            CheckBox checkBox = new CheckBox();
            checkBox.Content = user;

            UsersStackPanel.Children.Add(checkBox);
        }

        private User GetNewUser()
        {
            User user = new User();

            user.FirstName = FirstNameTextBox.Text;
            user.LastName = LastNameTextBox.Text;
            if (true == StudentRadioButton.IsChecked)
                user.Type = "Student";
            else if (true == EmployeeRadioButton.IsChecked)
                user.Type = "Employee";

            return user;
        }

        private void RemoveSelectedUsersButton_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < UsersStackPanel.Children.Count; i++)
            {
                CheckBox userCheckBox = UsersStackPanel.Children[i] as CheckBox;

                User user = userCheckBox.Tag as User;

                if (true == userCheckBox.IsChecked)
                {
                    UsersStackPanel.Children.Remove(userCheckBox);
                    --i;
                }
            }
        }
    }
}