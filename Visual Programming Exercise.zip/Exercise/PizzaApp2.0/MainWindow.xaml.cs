﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PizzaApp2._0
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// TODO: Figure out the bloody toppings issue
    public partial class MainWindow : Window
    {
        private double _total = 0;
        private double _toppings = 0;
        private double _size = 0;

        // made list global to use in both GetNewTopping() and GetNewSize()
        //might not be needed tho
        List<PizzaToppings> pizzaToppingsList = new List<PizzaToppings>();
        List<PizzaSize> pizzaSizesList = new List<PizzaSize>();

        public MainWindow()
        {
            InitializeComponent();
            InitializeSizes();
            InitializeToppings();
        }
        private void InitializeSizes()//initializes starter sizes
        {
            pizzaSizesList.Add(new PizzaSize("Small", 5.0));
            pizzaSizesList.Add(new PizzaSize("Medium", 6.5));
            pizzaSizesList.Add(new PizzaSize("Large", 7.25));

            foreach (PizzaSize entry in pizzaSizesList)
            {
                RadioButton pizzaSizeRadioButton = new RadioButton();
                pizzaSizeRadioButton.Content = entry.Name;
                pizzaSizeRadioButton.Tag = entry;

                pizzaSizeRadioButton.Checked += PizzaSizeRadio_Checked;
                pizzaSizeRadioButton.Unchecked += PizzaSizeRadio_Unchecked;

                pizzaSizeStack.Children.Add(pizzaSizeRadioButton);
            }
        }

        private void InitializeToppings()//initializes starter toppings
        {
            pizzaToppingsList.Add(new PizzaToppings("Tomato", 0.25));
            pizzaToppingsList.Add(new PizzaToppings("Mushroom", 0.5));
            pizzaToppingsList.Add(new PizzaToppings("Onion", 0.5));
            pizzaToppingsList.Add(new PizzaToppings("Pepperoni", 0.75));

            foreach (PizzaToppings entry in pizzaToppingsList)
            {
                CheckBox pizzaToppingsCheckBox = new CheckBox();
                pizzaToppingsCheckBox.Content = entry.Name;
                pizzaToppingsCheckBox.Tag = entry;

                pizzaToppingsCheckBox.Checked += PizzaToppingsCheckBox_Checked;
                pizzaToppingsCheckBox.Unchecked += PizzaToppingsCheckBox_Unchecked;

                pizzaToppingsStack.Children.Add(pizzaToppingsCheckBox);
            }
        }

        private void PizzaToppingsCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            PizzaToppings pizzaToppings = checkBox.Tag as PizzaToppings;
            _toppings -= pizzaToppings.Price;
            Update();
        }

        private void PizzaToppingsCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            PizzaToppings pizzaToppings = checkBox.Tag as PizzaToppings;
            _toppings += pizzaToppings.Price;
            Update();
        }
        private void PizzaSizeRadio_Unchecked(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            PizzaSize pizzaSize = radioButton.Tag as PizzaSize;
            _size -= pizzaSize.Price;
            Update();
        }

        private void PizzaSizeRadio_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            PizzaSize pizzaSize = radioButton.Tag as PizzaSize;
            _size += pizzaSize.Price;
            Update();
        }


        private void Update()
        {
            // couldnt get it to add toppings :(
            _total = 0;
            _total = _toppings + _size;
            priceLabel.Content = $"Total Price: ${_total.ToString()}";
        }

        private PizzaToppings GetNewToppings()//intializes new topping based on user input in text boxes
        {
            PizzaToppings pizzaToppings = new PizzaToppings();
            pizzaToppings.Name = addToppingName.Text;
            pizzaToppings.Price = Convert.ToDouble(addToppingPrice.Text);
            pizzaToppingsList.Add(pizzaToppings);
            return pizzaToppings;
        }

        private PizzaSize GetNewSize()//intializes new size based on user input in text boxes
        {
            PizzaSize pizzaSize = new PizzaSize();
            pizzaSize.Name = addSizeName.Text;
            pizzaSize.Price = Convert.ToDouble(addSizePrice.Text);
            pizzaSizesList.Add(pizzaSize);

            return pizzaSize;
        }

        private void addToppings_Click(object sender, RoutedEventArgs e)//shows new topping in display
        {
            PizzaToppings pizzaToppings = GetNewToppings();

            CheckBox pizzaToppingsCheckBox = new CheckBox();
            pizzaToppingsCheckBox.Content = pizzaToppings.Name;
            pizzaToppingsCheckBox.Tag = pizzaToppings;

            pizzaToppingsCheckBox.Checked += PizzaToppingsCheckBox_Checked;
            pizzaToppingsCheckBox.Unchecked += PizzaToppingsCheckBox_Unchecked;

            pizzaToppingsStack.Children.Add(pizzaToppingsCheckBox);
            
        }

        private void addSize_Click(object sender, RoutedEventArgs e)//shows new size on display
        {
            PizzaSize pizzaSize = GetNewSize();

            RadioButton pizzaSizeRadioButton = new RadioButton();
            pizzaSizeRadioButton.Content = pizzaSize.Name;
            pizzaSizeRadioButton.Tag = pizzaSize;

            pizzaSizeRadioButton.Checked += PizzaSizeRadio_Checked;
            pizzaSizeRadioButton.Unchecked += PizzaSizeRadio_Unchecked;

            pizzaSizeStack.Children.Add(pizzaSizeRadioButton);
        }

        private double toppingAddOn(PizzaToppings pizzaToppings)//to add toppings to price
        {
            double addOn = 0;
            
            return addOn;
        }
    }
}
