﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaApp2._0
{
    internal class PizzaToppings
    {
        public PizzaToppings(string name, double price)
        {
            Name = name;
            Price = price;
        }
        public PizzaToppings()
        {

        }
        public string Name { get; set; }

        public double Price { get; set; }
    }
}
