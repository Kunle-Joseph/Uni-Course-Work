﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwich_Shop
{
    class Breads
    {
        public Breads(double price, string name)
        {
            Price = price;
            Name = name;
        }

        public Breads() { }
        public double Price { get; set; }
        public string Name { get; set; }
    }
}
