﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sandwich_Shop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private double basePrice = 0;
        private double addOn = 0;
        private double finalPrice = 0;
        public MainWindow()
        {
            InitializeComponent();
            Login login = new Login();
            login.ShowDialog();
        }

        private void importBreads_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string breadList = File.ReadAllText(openFileDialog.FileName);
                List<Breads> breads = JsonConvert.DeserializeObject<List<Breads>>(breadList);

                foreach(var entry in breads)
                {
                    RadioButton breadButton = new RadioButton();

                    breadButton.Tag = entry;
                    breadButton.Content= $"{entry.Name} (${entry.Price.ToString("N2")})";

                    breadButton.Checked += BreadButton_Checked;
                    breadButton.Unchecked += BreadButton_Unchecked;

                    breadStack.Children.Add(breadButton);
                }

            }
        }

        private void BreadButton_Unchecked(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            Breads breads = radioButton.Tag as Breads;
            basePrice -= breads.Price;
            updatePrice();
        }

        private void BreadButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            Breads breads = radioButton.Tag as Breads;
            basePrice += breads.Price;
            updatePrice();
        }

        private void importItems_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string itemList = File.ReadAllText(openFileDialog.FileName);
                List<Items> items = JsonConvert.DeserializeObject<List<Items>>(itemList);

                foreach (var entry in items)
                {
                    CheckBox itemButton = new CheckBox();

                    itemButton.Tag = entry;

                    if (entry.IsVegetarian == true)
                        itemButton.Content = $"[V] {entry.Name} (${entry.Price.ToString("N2")})";

                    else
                        itemButton.Content = $"{entry.Name} (${entry.Price.ToString("N2")})";

                    itemButton.Checked += ItemButton_Checked;
                    itemButton.Unchecked += ItemButton_Unchecked;

                    itemStack.Children.Add(itemButton);
                }

            }
        }

        private void ItemButton_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            Items items = checkBox.Tag as Items;
            addOn -= items.Price;
            updatePrice();
        }

        private void ItemButton_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            Items items = checkBox.Tag as Items;
            addOn += items.Price;
            updatePrice();
        }

        private void updatePrice()
        {
            double total = 0;
            total = basePrice + addOn;
            priceBox.Text = $"Total Price: ${total.ToString("N2")}";
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            Sandwich sandwich = new Sandwich();

            for (int i = 0; i < breadStack.Children.Count; i++)
            {
                RadioButton radio = breadStack.Children[i] as RadioButton;
                if(radio.IsChecked == true)
                {
                    sandwich.breads = (Breads)radio.Tag;
                }
            }

            List<Items> itemList = new List<Items>();
            for (int i = 0; i < itemStack.Children.Count; i++)
            {
                CheckBox check = itemStack.Children[i] as CheckBox;
                if (check.IsChecked == true)
                {
                    itemList.Add((Items)check.Tag);
                }
            }

            sandwich.items = itemList;

            CheckBox orderBox = new CheckBox();
            orderBox.Tag = sandwich;
            orderBox.Content = sandwich.getDisplayName() + $" ($ {sandwich.getPrice().ToString("N2")})";

            orderBox.Checked += OrderBox_Checked;
            orderBox.Unchecked += OrderBox_Unchecked;

            orderStack.Children.Add(orderBox);

            //unchecking the boxes for convenience sake
            for (int i = 0; i < breadStack.Children.Count; i++)
            {
                RadioButton radio = breadStack.Children[i] as RadioButton;
                if (radio.IsChecked == true)
                {
                    radio.IsChecked = false;
                }
            }

            for (int i = 0; i < itemStack.Children.Count; i++)
            {
                CheckBox check = itemStack.Children[i] as CheckBox;
                if (check.IsChecked == true)
                {
                    check.IsChecked= false;
                }
            }
        }

        private void OrderBox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            Sandwich order = checkBox.Tag as Sandwich;
            finalPrice -= order.getPrice();
        }

        private void OrderBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            Sandwich order = checkBox.Tag as Sandwich;
            finalPrice += order.getPrice();
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < orderStack.Children.Count; i++)
            {
                CheckBox orders = orderStack.Children[i] as CheckBox;
                if(orders.IsChecked == true)
                {
                    Sandwich removed = orders.Tag as Sandwich;
                    finalPrice -= removed.getPrice();
                    orderStack.Children.Remove(orders);
                }
            }
        }

        private void orderButton_Click(object sender, RoutedEventArgs e)
        {
            int count = 0;
            for (int i = 0; i < orderStack.Children.Count; i++)
            {
                CheckBox orders = orderStack.Children[i] as CheckBox;
                if (orders.IsChecked == true)
                {
                    count++;
                }
            }
            if (count == 0)
            {
                MessageBox.Show("Please pick an Order", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var dr = MessageBox.Show($"Are you sure you want to place order of listed sandwich(es) for " +
                $"{finalPrice}?","Order Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (dr == MessageBoxResult.Yes)
            {
                MessageBox.Show("Thank you for placing order", "Thank you", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                this.Close();
            }
        }
    }
}
