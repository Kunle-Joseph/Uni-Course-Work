﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwich_Shop
{
    class Items
    {
        public Items(double price, string name, bool isVegetarian)
        {
            Price = price;
            Name = name;
            IsVegetarian = isVegetarian;
        }

        Items() { }
        public double Price { get; set; }
        public string Name { get; set; }
        public bool IsVegetarian { get; set; }
    }
}
