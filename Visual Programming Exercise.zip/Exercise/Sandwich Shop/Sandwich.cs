﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwich_Shop
{
    internal class Sandwich
    {
        public Sandwich(Breads bread, List<Items> item)
        {
            breads= bread;
            items = item;
        }

        public Sandwich()
        {
        }

        public Breads breads { get; set; }
        public List<Items> items { get; set; }

        public double getPrice()
        {
            double total = 0;
            foreach (Items item in items)
            {
                total += item.Price;
            }
            return breads.Price + total;
        }

        public string getDisplayName()
        {
            string itemDisplay = "";
            foreach (Items item in items)
            {
                itemDisplay += item.Name + ", ";
            }
            return breads.Name + ", " + itemDisplay;
        }
    }
}
