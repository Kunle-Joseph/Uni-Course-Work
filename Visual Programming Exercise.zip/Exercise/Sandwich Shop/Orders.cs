﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandwich_Shop
{
    class Orders
    {
        public Orders() {
            Items = "";
        }

        public Orders(string items, double price)
        {
            Items = items;
            Price = price;
        }

        public String Items { get; set; }
        public double Price { get; set; }
    }
}
