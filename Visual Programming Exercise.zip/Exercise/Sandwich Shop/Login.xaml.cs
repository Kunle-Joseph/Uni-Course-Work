﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Sandwich_Shop
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        List<User> users = new List<User>();
        public Login()
        {
            InitializeComponent();
            users.Add(new User("Kunle", "Joseph"));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            foreach(User users in users)
            {
                if(UserTextBox.Text == users.Name && PasswordTextBox.Text == users.Password)
                {
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Login", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
            }
        }
    }
}
