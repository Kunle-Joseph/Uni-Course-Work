﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalPractices
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Tax_Calculator tax = new Tax_Calculator();
        ShoppingListWindow shop = new ShoppingListWindow();
        HouseCustomizerWindow house = new HouseCustomizerWindow();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void shopButton_Click(object sender, RoutedEventArgs e)
        {
            shop.Show();
        }

        private void taxButton_Click(object sender, RoutedEventArgs e)
        {
            tax.Show();
        }

        private void houseButton_Click(object sender, RoutedEventArgs e)
        {
            house.Show();
        }
    }
}
