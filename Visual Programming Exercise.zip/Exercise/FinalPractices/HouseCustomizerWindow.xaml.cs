﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalPractices
{
    /// <summary>
    /// Interaction logic for HouseCustomizerWindow.xaml
    /// </summary>
    public partial class HouseCustomizerWindow : Window
    {
        public HouseCustomizerWindow()
        {
            InitializeComponent();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void submitButton_Click(object sender, RoutedEventArgs e)
        {
            if (inputCheck())
            {
                String color = "" , rooms = "", options = "";
                for (int i = 0; i < radioWrap.Children.Count; i++)
                {
                    RadioButton radio = radioWrap.Children[i] as RadioButton;
                    if (radio.IsChecked == true)
                    {
                        color = radio.Content.ToString();
                        break;
                    }
                }
                rooms = textBox.Text;
                for(int i = 0; i < checkBoxWrap.Children.Count; i++)
                {
                    CheckBox check = checkBoxWrap.Children[i] as CheckBox;
                    if(check.IsChecked == true)
                    {
                        options += check.Content.ToString() + ", ";
                    }
                }
                if(options != "")
                {
                    var response = MessageBox.Show($"Please confirm you are looking for a house with {color} walls " +
                    $"and {rooms} bedrooms with the following options: {options}", "Description",
                    MessageBoxButton.YesNo, MessageBoxImage.Exclamation);

                    if (response == MessageBoxResult.Yes)
                    {
                        MessageBox.Show("Thank You");
                    }
                }
                else
                {
                    var response = MessageBox.Show($"Please confirm you are looking for a house with {color} walls " +
                    $"and {rooms} bedrooms.", "Description",
                    MessageBoxButton.YesNo, MessageBoxImage.Exclamation);

                    if (response == MessageBoxResult.Yes)
                    {
                        MessageBox.Show("Thank You");
                    }
                }
                
            }
        }

        private bool inputCheck()
        {
            int j;
            if (textBox.Text == "")
            {
                MessageBox.Show("Please type in something", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            else if (int.TryParse(textBox.Text, out j) == false)
            {
                MessageBox.Show("Please type in a number", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            int count = 0;
            for (int i = 0; i < radioWrap.Children.Count; i++)
            {
                RadioButton radio = radioWrap.Children[i] as RadioButton;
                if (radio.IsChecked == true)
                {
                    count++;
                }
            }
            if (count == 0)
            {
                MessageBox.Show("Please pick a color", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }
    }
}
