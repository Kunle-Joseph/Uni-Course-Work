﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalPractices
{
    /// <summary>
    /// Interaction logic for ShoppingListWindow.xaml
    /// </summary>
    public partial class ShoppingListWindow : Window
    {
        public ShoppingListWindow()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            if (entryCheck())
            {
                CheckBox check = new CheckBox();
                check.Content = quantityBox.Text + "x " + itemBox.Text;
                itemStack.Children.Add(check);
                quantityBox.Text = string.Empty;
                itemBox.Text = string.Empty;
            }
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < itemStack.Children.Count; i++)
            {
                CheckBox check = itemStack.Children[i] as CheckBox;
                if (check.IsChecked == true)
                {
                    itemStack.Children.Remove(check);
                    --i;
                }
            }
        }

        private bool entryCheck()
        {
            if(string.IsNullOrEmpty(itemBox.Text) || string.IsNullOrEmpty(quantityBox.Text))
            {
                MessageBox.Show("Please fill in the boxes", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            int i;
            if (int.TryParse(quantityBox.Text, out i) == false)
            {
                MessageBox.Show("Please type in a whole number for quantity", "Error", MessageBoxButton.OK, 
                    MessageBoxImage.Error);
                return false;
            }
            return true;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
