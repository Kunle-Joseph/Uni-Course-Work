﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalPractices
{
    /// <summary>
    /// Interaction logic for Tax_Calculator.xaml
    /// </summary>
    public partial class Tax_Calculator : Window
    {
        double amount = 0, social, tax, net;
        int months;
        const double Tax_Threshold = 25000;
        public Tax_Calculator()
        {
            InitializeComponent();
        }

        private void monthlyRadio_Click(object sender, RoutedEventArgs e)
        {
            update();
        }

        private void annualRadio_Click(object sender, RoutedEventArgs e)
        {
            update();

        }

        private void monthCheckBox_Click(object sender, RoutedEventArgs e)
        {
            update();

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (monthlyRadio.IsChecked == false && annualRadio.IsChecked == false)
            {
                MessageBox.Show("Please click one of the radio buttons", "Error", MessageBoxButton.OK,
                    MessageBoxImage.Error);
                TextBox.Text = string.Empty;
                return;
            }
            update();
        }

        private void update()
        {
            if (monthCheckBox.IsChecked == true)
                months = 13;
            else
                months = 12;
            if (double.TryParse(TextBox.Text, out amount) == true)
            {
                if (monthlyRadio.IsChecked == true)
                {
                    monthlyGross.Text = amount.ToString("N2");

                    social = (amount * (4.56 / 100));
                    if ((amount - social) < Tax_Threshold)
                        tax = 0;
                    else
                        tax = (amount - social - Tax_Threshold) * 0.1;
                    net = amount - (social + tax);

                    //monthly
                    monthlyNet.Text = $"$ {net.ToString("N2")}";
                    monthlyTax.Text = $"$ {tax.ToString("N2")}";
                    monthlySocial.Text = $"$ {social.ToString("N2")}";

                    //annual
                    annualGross.Text = $"$ {(amount * months).ToString("N2")}";
                    annualNet.Text = $"$ {(net * months).ToString("N2")}";
                    annualTax.Text = $"$ {(tax * months).ToString("N2")}";
                    annualSocial.Text = $"$ {(social * months).ToString("N2")}";
                }
                else
                {
                    annualGross.Text = amount.ToString("N2");

                    social = (amount * (4.56 / 100));
                    if ((amount - social) < Tax_Threshold)
                        tax = 0;
                    else
                        tax = (amount - social - Tax_Threshold) * 0.1;
                    net = amount - (social + tax);

                    //annual
                    annualNet.Text = $"$ {net.ToString("N2")}";
                    annualTax.Text = $"$ {tax.ToString("N2")}";
                    annualSocial.Text = $"$ {social.ToString("N2")}";

                    //monthly
                    monthlyGross.Text = $"$ {(amount / months).ToString("N2")}";
                    monthlyNet.Text = $"$ {(net / months).ToString("N2")}";
                    monthlyTax.Text = $"$ {(tax / months).ToString("N2")}";
                    monthlySocial.Text = $"$ {(social / months).ToString("N2")}";
                }
            }
        }
    }
}
