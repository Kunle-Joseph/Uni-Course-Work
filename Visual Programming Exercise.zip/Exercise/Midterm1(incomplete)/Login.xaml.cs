﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Midterm
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        MainWindow main = new MainWindow();
        List<User> users = new List<User>();
        public Login()
        {
            InitializeComponent();
            users.Add(new User("You", "May pass"));
        }

        private void loginButton_Click(object sender, RoutedEventArgs e)
        {
            foreach (User users in users)
            {
                if (userTextBox.Text == users.Name && passwordTextBox.Text == users.Password)
                {
                    main.Show();//didnt get chance to test this
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Login", "Error", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
            }
        }
    }
}
