﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Midterm
{
    /// <summary>
    /// Interaction logic for Drinks.xaml
    /// </summary>
    public partial class Drinks : Window
    {
        public List<Drink> drinkList = new List<Drink>();
        public Drinks()
        {
            InitializeComponent();
            drinkList.Add(new Drink("Coke", 0.9));
            drinkList.Add(new Drink("Fanta", 0.9));
            drinkList.Add(new Drink("Sprite", 0.9));
            fillDrinkStack();
        }

        private void addNewDrink_Click(object sender, RoutedEventArgs e)
        {
            if (addDrinkName.Text == "" || addDrinkPrice.Text == "")
            {
                MessageBox.Show("Please fill all fields", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                //clearing text boxes
                addDrinkName.Text = "";
                addDrinkPrice.Text = "";
                return;
            }

            Drink newDrink = new Drink(addDrinkName.Text, Convert.ToDouble(addDrinkPrice.Text));
            TextBlock textBlock = new TextBlock();
            textBlock.Tag = newDrink;
            textBlock.Text = $"{newDrink.Name} ($ {newDrink.Price.ToString("N2")})";
            addDrinkStack.Children.Add(textBlock);
            drinkList.Add(newDrink);

            //clearing text boxes
            addDrinkName.Text = "";
            addDrinkPrice.Text = "";
        }

        private void fillDrinkStack()
        {
            if (drinkList.Count > 0)
            {
                foreach (Drink drink in drinkList)
                {
                    TextBlock textBlock = new TextBlock();
                    textBlock.Tag = drink;
                    textBlock.Text = $"{drink.Name} ($ {drink.Price.ToString("N2")})";
                    addDrinkStack.Children.Add(textBlock);
                }
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }
    }
}
