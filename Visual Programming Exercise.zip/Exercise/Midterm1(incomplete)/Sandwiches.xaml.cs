﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Midterm
{
    /// <summary>
    /// Interaction logic for Sandwiches.xaml
    /// </summary>
    public partial class Sandwiches : Window
    {
        public List<Sandwich> sandwichList = new List<Sandwich>();
        MainWindow main = ((MainWindow)System.Windows.Application.Current.MainWindow);
        public Sandwiches()
        {
            InitializeComponent();
            sandwichList.Add(new Sandwich("Rye", 1));//test value
            sandwichList.Add(new Sandwich("Wheat", 0.5));
            sandwichList.Add(new Sandwich("Whole", .25));
            fillSandwichStack();
        }

        private void addNewSandwich_Click(object sender, RoutedEventArgs e)
        {
            if (addSandwichName.Text == "" || addSandwichPrice.Text == "")
            {
                MessageBox.Show("Please fill all fields", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                //clearing text boxes
                addSandwichName.Text = "";
                addSandwichPrice.Text = "";
                return;
            }

            Sandwich newSandwich = new Sandwich(addSandwichName.Text, Convert.ToDouble(addSandwichPrice.Text));
            TextBlock textBlock= new TextBlock();
            textBlock.Tag = newSandwich;
            textBlock.Text = $"{newSandwich.Name} ($ {newSandwich.Price.ToString("N2")})";
            addSandwichStack.Children.Add(textBlock);
            sandwichList.Add(newSandwich);

            CheckBox checkBox= new CheckBox();
            checkBox.Tag = newSandwich;
            checkBox.Content = $"{newSandwich.Name} ($ {newSandwich.Price.ToString("N2")})";
            main.sandwichStack.Children.Add(checkBox);

            //clearing text boxes
            addSandwichName.Text = "";
            addSandwichPrice.Text = "";
        }

        private void fillSandwichStack()
        {
            if (sandwichList.Count > 0)
            {
                foreach (Sandwich sandwich in sandwichList)
                {
                    TextBlock textBlock = new TextBlock();
                    textBlock.Tag = sandwich;
                    textBlock.Text = $"{sandwich.Name} ($ {sandwich.Price.ToString("N2")})";
                    addSandwichStack.Children.Add(textBlock);
                }
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }
    }
}
