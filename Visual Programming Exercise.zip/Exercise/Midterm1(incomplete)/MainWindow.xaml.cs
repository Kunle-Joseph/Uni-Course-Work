﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Midterm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Sandwiches sandwichPage = new Sandwiches();
        Drinks drinksPage = new Drinks();
        double finalPrice = 0;
        public MainWindow()
        {
            InitializeComponent();
            FillSandwichStack();
            FillDrinkStack();
            
        }

        private void addSandwiches_Click(object sender, RoutedEventArgs e)
        {
            sandwichPage.Visibility = Visibility.Visible;
            sandwichPage.Owner = this;
        }

        private void addDrinks_Click(object sender, RoutedEventArgs e)
        {
            drinksPage.Visibility= Visibility.Visible;
            drinksPage.Owner = this;
        }

        public void FillSandwichStack()
        {
            if(sandwichPage.sandwichList.Count > 0)
            {
                foreach (Sandwich sandwich in sandwichPage.sandwichList)
                {
                    CheckBox sandwichCheckBox= new CheckBox();
                    sandwichCheckBox.Tag = sandwich;
                    sandwichCheckBox.Content = $"{sandwich.Name} ($ {sandwich.Price.ToString("N2")})";
                    sandwichStack.Children.Add(sandwichCheckBox);

                    sandwichCheckBox.Checked += sandwichCheckBox_checked;
                    sandwichCheckBox.Unchecked += sandwichCheckBox_Unchecked;
                }
            }
        }

        public void FillDrinkStack()
        {
            if (drinksPage.drinkList.Count > 0)
            {
                foreach (Drink drink in drinksPage.drinkList)
                {
                    CheckBox drinkCheckBox = new CheckBox();
                    drinkCheckBox.Tag = drink;
                    drinkCheckBox.Content = $"{drink.Name} ($ {drink.Price.ToString("N2")})";
                    drinkStack.Children.Add(drinkCheckBox);

                    drinkCheckBox.Checked += drinkCheckBox_Checked;
                    drinkCheckBox.Unchecked += drinkCheckBox_Unchecked;
                }
            }
        }

        private void drinkCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            Drink drink = checkBox.Tag as Drink;
            finalPrice -= drink.Price;
            priceUpdate();
        }

        private void drinkCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            Drink drink = checkBox.Tag as Drink;
            finalPrice += drink.Price;
            priceUpdate();
        }

        private void sandwichCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            Sandwich sandwich = checkBox.Tag as Sandwich;
            finalPrice -= sandwich.Price;
            priceUpdate();
        }

        private void sandwichCheckBox_checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            Sandwich sandwich = checkBox.Tag as Sandwich;
            finalPrice += sandwich.Price;
            priceUpdate();
        }

        private void priceUpdate()
        {
            priceBlock.Text = $"$ {finalPrice.ToString("N2")}";
        }

        private void orderButton_Click(object sender, RoutedEventArgs e)
        {
            int count = 0;
            for (int i =0; i < sandwichStack.Children.Count; i++)
            {
                CheckBox order = sandwichStack.Children[i] as CheckBox;
                if (order.IsChecked == true) count++;
            }
            for (int i = 0; i < drinkStack.Children.Count; i++)
            {
                CheckBox order = drinkStack.Children[i] as CheckBox;
                if (order.IsChecked == true) count++;
            }
            if (count == 0)
            {
                MessageBox.Show("Please pick an Order", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var dr = MessageBox.Show($"Are you sure you want to place order of listed items for " +
                $"{finalPrice}?", "Order Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (dr == MessageBoxResult.Yes)
            {
                MessageBox.Show("Thank you for placing order", "Thank you", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                this.Close();
            }
        }
    }
}