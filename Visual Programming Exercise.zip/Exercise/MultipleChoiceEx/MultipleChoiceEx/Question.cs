﻿using System.Collections.Generic;

namespace tstWpf
{
    internal class Question
    {
        public Question(string text, string correctAnswer, List<string> wrongAnswers)
        {
            Text = text;
            CorrectAnswer = correctAnswer;
            WrongAnswers = wrongAnswers;
        }

        public string Text { get; set; }
        public List<string> WrongAnswers { get; set; }
        public string CorrectAnswer { get; set; }
    }
}