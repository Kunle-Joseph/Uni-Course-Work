﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace tstWpf
{
    /// <summary>
    /// Interaction logic for MultipleChoiceExamExercise.xaml
    /// </summary>
    public partial class MultipleChoiceExamExercise : Window
    {
        public MultipleChoiceExamExercise()
        {
            InitializeComponent();

            InitializeQuestions();
        }

        private List<Question> questions;
        private int _activeQuestionIndex = -1;
        private int _activeQuestionAnswerIndex = -1;
        private int _correctAnswerCount = 0;

        private void InitializeQuestions()
        {
            questions = new List<Question>();
            questions.Add(new Question("Which one is Correct?", "Correct", new List<string> { "Wrong1", "Wrong2", "Wrong3" }));
            questions.Add(new Question("What programming language are we using in class?", "C#", new List<string> { "C++", "Java", "JS" }));
            questions.Add(new Question("Which country is not in Europe?", "Japan", new List<string> { "France", "Germany", "Cyprus" }));

            DisplayNextQuestion();
        }

        /// <summary>
        /// Displays next question
        /// </summary>
        private void DisplayNextQuestion()
        {
            ++_activeQuestionIndex;

            Question activeQuestion = questions[_activeQuestionIndex];

            // [Question Text]
            QuestionLabel.Content = activeQuestion.Text;

            // [Randomized Choices]
            List<string> choiceTexts = new List<string>();
            choiceTexts.Add(activeQuestion.CorrectAnswer);

            Random rnd = new Random();
            foreach (string wrongAnswer in activeQuestion.WrongAnswers)
            {
                // Randomly insert the wrong answers to shuffle the choices
                choiceTexts.Insert(rnd.Next(0, choiceTexts.Count + 1), wrongAnswer);
            }

            ChoiceARadioButton.Content = choiceTexts[0];
            ChoiceBRadioButton.Content = choiceTexts[1];
            ChoiceCRadioButton.Content = choiceTexts[2];
            ChoiceDRadioButton.Content = choiceTexts[3];

            // [Remember the answer index]
            for (int i = 0; i < choiceTexts.Count; ++i)
            {
                if (choiceTexts[i] == activeQuestion.CorrectAnswer)
                {
                    _activeQuestionAnswerIndex = i;
                    break;
                }
            }

            // [Clear RadioButtons]
            ChoiceARadioButton.IsChecked = false;
            ChoiceBRadioButton.IsChecked = false;
            ChoiceCRadioButton.IsChecked = false;
            ChoiceDRadioButton.IsChecked = false;
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (IsAnswerCorrect())
                ++_correctAnswerCount;

            if (_activeQuestionIndex == questions.Count - 1)
                DisplayFinalScore();
            else
                DisplayNextQuestion();
        }

        private bool IsAnswerCorrect()
        {
            if (true == ChoiceARadioButton.IsChecked)
                return _activeQuestionAnswerIndex == 0;
            else if (true == ChoiceBRadioButton.IsChecked)
                return _activeQuestionAnswerIndex == 1;
            else if (true == ChoiceCRadioButton.IsChecked)
                return _activeQuestionAnswerIndex == 2;
            else if (true == ChoiceDRadioButton.IsChecked)
                return _activeQuestionAnswerIndex == 3;
            // No answer
            else
                return false;
        }

        private void DisplayFinalScore()
        {
            // [ Hide question-related controls ]
            QuestionLabel.Visibility = Visibility.Collapsed;
            ChoiceARadioButton.Visibility = Visibility.Collapsed;
            ChoiceBRadioButton.Visibility = Visibility.Collapsed;
            ChoiceCRadioButton.Visibility = Visibility.Collapsed;
            ChoiceDRadioButton.Visibility = Visibility.Collapsed;
            SubmitButton.Visibility = Visibility.Collapsed;

            // [ Show score and set the value ]
            FinalScoreLabel.Visibility = Visibility.Visible;
            FinalScoreLabel.Content = $"You answers {_correctAnswerCount} / {questions.Count} questions correctly.";
        }
    }
}