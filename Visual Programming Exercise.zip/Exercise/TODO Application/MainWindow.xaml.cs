﻿using Newtonsoft.Json;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace TODO_Application
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        

        private void addTasksButton_Click(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = new CheckBox();
            checkBox.Content = tasksTextBox.Text;

            taskStack.Children.Add(checkBox);
            tasksTextBox.Text = "";
        }

        private void removeTasksButton_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < taskStack.Children.Count; i++)
            {
                CheckBox taskCheckBox = taskStack.Children[i] as CheckBox;
                if (taskCheckBox.IsChecked == true)
                {
                    taskStack.Children.Remove(taskCheckBox);
                    --i;
                }
            }
        }


        private void importTasksButton_Click(object sender, RoutedEventArgs e)
        {
            // Load students from the file.
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string fileContent = File.ReadAllText(openFileDialog.FileName);

                // Splits string into an array of strings based on given value
                // This will have the same entries as tasks
                var separatedTasks = fileContent.Split(Environment.NewLine);
                foreach (var task in separatedTasks)
                {
                    CheckBox checkBox = new CheckBox();
                    checkBox.Content = task;

                    taskStack.Children.Add(checkBox);
                    tasksTextBox.Text = "";
                }
            }
        }

        private void exportTasksButton_Click(object sender, RoutedEventArgs e)
        {
            // Export the selected task where the user is asking
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            if (saveFileDialog.ShowDialog() == true)
            {
                List<Tasks> tasks = GetSelectedTask();

                if (tasks.Count == 0)
                {
                    MessageBox.Show("Please select at least 1 task.", "No Task Selected", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    foreach(Tasks tasks1 in tasks)
                    {
                    // Adds strings together using the given value (Here: NewLine) as delimiter
                    string mergedTasks = string.Join(Environment.NewLine, tasks1);
                    File.WriteAllText(saveFileDialog.FileName, mergedTasks);
                    }
                }

                
            }
        }

        private List<Tasks> GetSelectedTask()
        {
            List<Tasks> task = new List<Tasks>();

            foreach (CheckBox taskCheckBox in taskStack.Children)
            {
                if (taskCheckBox.IsChecked == true)
                {
                    Tasks selectedTask = taskCheckBox.Content as Tasks;
                    task.Add(selectedTask);
                }
            }

            return task;
        }
    }
}
