﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TODO_Application
{
    internal class Tasks
    {
        public Tasks(string task)
        {
            this.task = task;
        }

        public string task { get; set; }
    }
}
