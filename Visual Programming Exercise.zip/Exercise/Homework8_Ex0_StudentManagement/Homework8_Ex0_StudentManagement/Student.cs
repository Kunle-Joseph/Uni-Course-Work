﻿using System;

namespace Homework8_Ex0_StudentManagement
{
    internal class Student
    {
        public Student()
        {
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string ClassStanding { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string PostCode { get; set; }
    }
}