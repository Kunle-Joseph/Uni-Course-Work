﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hw4Ex3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<User> users = new List<User>();
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void loginButton_Click(object sender, RoutedEventArgs e)
        {
            users.Add(new User("Kunle", "Joseph"));//example
            foreach(User user in users)
            {
                if(user.Name == userTextBox.Text && user.Password == passwordTextBox.Text)
                {
                    MessageBox.Show("Successful login", "Login Menu", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
                else
                {
                    MessageBox.Show("Failed login", "Login Menu", MessageBoxButton.OK, MessageBoxImage.Error);

                }
            }
            //reset text boxes
            userTextBox.Text = "";
            passwordTextBox.Text = "";
        }
    }
}
